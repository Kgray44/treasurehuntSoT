import { openSync, appendFileSync, fsyncSync, closeSync } from "node:fs";
const output = openSync("D:\\CodexTemp\\sounding-line-crossdeck-r11-20261016\\merged-policy-db5243ed\\registered-policy.progress.jsonl", "wx");
export default async function* report(source) {
 try {
  for await (const { type, data } of source) {
    if (!["test:dequeue", "test:complete", "test:summary"].includes(type)) continue;
    appendFileSync(output, JSON.stringify({ observedAt: new Date().toISOString(), type,
file: data.entryFile ?? data.file, name: data.name, nesting: data.nesting,
line: data.line, column: data.column, testId: data.testId, parentId: data.parentId,
passed: data.details?.passed, durationMs: data.details?.duration_ms,
counts: data.counts }) + "\n");
    fsyncSync(output);
  }
 } finally { closeSync(output); }
}
