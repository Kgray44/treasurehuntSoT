import hashlib,json,pathlib,zipfile,datetime
root=pathlib.Path('D:/CodexTemp/sounding-line-crossdeck-r11-20261016')
prior=pathlib.Path('D:/CodexTemp/sounding-line-replay-diagnostics-20261016')
def sha_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while data:=f.read(1024*1024):h.update(data)
    return h.hexdigest()
handoff=json.loads((root/'accepted-main-handoff.json').read_text())
assert handoff['status']=='ACCEPTED'
dest=root/'accepted-authority-originals.zip'
assert not dest.exists()
excluded_names={'accepted-authority-originals.zip','accepted-authority-preservation-index.json','accepted-authority-archive-verification.json'}
entries=[];external=[]
files=[(p,p.relative_to(root).as_posix()) for p in sorted(root.rglob('*')) if p.is_file() and p.name not in excluded_names]
for name in ['accepted-main-handoff.json','accepted-authority-originals.zip','accepted-authority-preservation-index.json','landed-verification-receipt.json']:
    p=prior/name;assert p.is_file();files.append((p,'accepted-prerequisite-753/'+name))
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path,name in files:
        row={'file':name,'originalPath':str(path),'bytes':path.stat().st_size,'sha256':sha_file(path)}
        if row['bytes']>64*1024*1024:
            assert path.name=='http-0004.zip'
            assert row['bytes']==1405907736 and row['sha256']=='00d3706a20bfb1c9ec9f60bf6daabd58a4c10a298dcc9512dc5845cabf36d754'
            row['classification']='EXTERNAL_UNCHANGED_ORIGINAL_HISTORICAL_CAPTURE_ARTIFACT_12048176159_NOT_FRESH_REPLAY'
            external.append(row)
        else:
            z.write(path,name);entries.append(row)
index={'classification':'ACCEPTED_R11_PROTECTED_INSTALLATION_PRESERVATION_WITH_ALL_FAILURES_RETAINED_NOT_CONSUMER_QUALIFICATION','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'acceptedMainSha':handoff['acceptedMainSha'],'sourceCandidate':handoff['sourceCandidate'],'entries':entries,'externalLargeOriginals':external,'externalOriginalsAreHashBoundAndRehashed':True,'zip':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha_file(dest)}}
with (root/'accepted-authority-preservation-index.json').open('x',encoding='utf8') as f:json.dump(index,f,indent=2);f.write('\n')
verified=0
with zipfile.ZipFile(dest) as z:
    assert len(z.infolist())==len(entries)
    for row in entries:
        data=z.read(row['file']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];verified+=1
verification={'status':'PASS','acceptedMainSha':handoff['acceptedMainSha'],'archive':index['zip'],'verifiedArchiveEntries':verified,'externalOriginalsRehashed':external,'preservationIndexSha256':sha_file(root/'accepted-authority-preservation-index.json')}
with (root/'accepted-authority-archive-verification.json').open('x',encoding='utf8') as f:json.dump(verification,f,indent=2);f.write('\n')
print(json.dumps(verification,indent=2))
