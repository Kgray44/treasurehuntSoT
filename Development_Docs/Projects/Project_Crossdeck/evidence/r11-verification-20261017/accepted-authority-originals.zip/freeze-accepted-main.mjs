import fs from 'node:fs';import cp from 'node:child_process';import assert from 'node:assert/strict';
const out='D:/CodexTemp/sounding-line-crossdeck-r11-20261016',api=(route,file)=>{const bytes=cp.execFileSync('gh',['api','repos/Kgray44/treasurehuntSoT/'+route],{maxBuffer:16*1024*1024,stdio:['ignore','pipe','pipe']});fs.writeFileSync(out+'/'+file,bytes,{flag:'wx'});return JSON.parse(bytes);};
const pr=api('pulls/754','accepted-pr.original.raw.json');assert.equal(pr.merged,true);assert.equal(pr.head.sha,'db5243edc78d7fd42b9af6db007a8e68f5ea25b6');
const ref=api('git/ref/heads/main','accepted-main-ref.original.raw.json');assert.equal(ref.object.sha,pr.merge_commit_sha);
const commit=api('git/commits/'+pr.merge_commit_sha,'accepted-main.original.raw.json');assert.equal(commit.tree.sha,'7b325d144a35d0e3e993a09cda8ced46ee783d3f');assert(commit.parents.some(p=>p.sha===pr.head.sha));assert(commit.parents.some(p=>p.sha==='e1ad5874661c30c02b7d80173423a6eef0cb19e5'));
console.log(JSON.stringify({acceptedMainSha:commit.sha,tree:commit.tree.sha,mergedAt:pr.merged_at}));
