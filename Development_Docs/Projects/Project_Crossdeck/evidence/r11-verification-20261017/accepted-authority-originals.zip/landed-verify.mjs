import fs from 'node:fs';
import cp from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='D:/CodexWorktrees/sounding-line-crossdeck-r11-landed-20261016',out='D:/CodexTemp/sounding-line-crossdeck-r11-20261016',head=process.argv[2],tree='7b325d144a35d0e3e993a09cda8ced46ee783d3f',source='db5243edc78d7fd42b9af6db007a8e68f5ea25b6';
const hash=b=>createHash('sha256').update(b).digest('hex'),git=(...args)=>cp.execFileSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:64*1024*1024}).trim();
const save=(file,data)=>fs.writeFileSync(out+'/'+file,typeof data==='string'||Buffer.isBuffer(data)?data:JSON.stringify(data,null,2)+'\n',{flag:'wx'});
assert.match(head,/^[a-f0-9]{40}$/);assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('rev-parse','HEAD^{tree}'),tree);assert.equal(git('status','--porcelain'),'');git('merge-base','--is-ancestor',source,head);
const before=git('ls-tree','-rz','HEAD'),phase=()=>{const dir=root+'/artifacts/sounding-line';return fs.existsSync(dir)?fs.readdirSync(dir).filter(n=>/^exception-.*\.json$/.test(n)||n==='product-experience-plan.json').sort().map(n=>({name:n,sha256:hash(fs.readFileSync(dir+'/'+n))})):[];},phaseBefore=phase();assert.deepEqual(phaseBefore,[]);
const manifest=JSON.parse(fs.readFileSync(out+'/source-manifest-db5243ed.json','utf8'));
assert.equal(manifest.head,source);assert.equal(manifest.tree,tree);
for(const entry of manifest.entries){assert.equal(git('rev-parse',head+':'+entry.path),entry.blob);assert.equal(hash(fs.readFileSync(root+'/'+entry.path)),entry.workingSha256);}
const env={...process.env,GITHUB_ACTIONS:'true',GITHUB_JOB:'final-check',SOUNDING_LINE_PR_NUMBER:'721',SOUNDING_LINE_EXCEPTION_PHASE:'qualify',SOUNDING_LINE_EXCEPTION_LEASE:'INERT_LANDED_UNIT_FIXTURE',SOUNDING_LINE_EXCEPTION_ORDINARY_LEASE:'INERT_LANDED_UNIT_FIXTURE'};
for(const key of Object.keys(env))if(/(?:TOKEN|SECRET|PASSWORD|CREDENTIAL)/i.test(key)||/^SOUNDING_LINE_R(?:9|10|11)_CONSUMER_POLICY_FIXTURE$/.test(key))delete env[key];
const rows=[];
async function run(name,exe,args){const startedAt=new Date().toISOString(),stdout=fs.openSync(out+'/'+name+'.stdout.txt','wx'),stderr=fs.openSync(out+'/'+name+'.stderr.txt','wx');const child=cp.spawn(exe,args,{cwd:root,env,stdio:['ignore',stdout,stderr],windowsHide:true});const result=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal}));});fs.closeSync(stdout);fs.closeSync(stderr);const row={name,command:[exe,...args],startedAt,completedAt:new Date().toISOString(),...result};save(name+'.terminal.json',row);assert.equal(result.code,0,name);assert.equal(result.signal,null);rows.push(row);console.log(JSON.stringify(row));}
await run('landed-smoke',process.execPath,['--test','--test-name-pattern=R11','tests/sounding-line/experience-exception.test.mjs']);
for(const [name,task] of [['landed-docs','docs:validate'],['landed-features-sync','features:sync'],['landed-features-validate','features:validate']])await run(name,process.env.ComSpec??'C:/Windows/System32/cmd.exe',['/d','/s','/c','npm run '+task]);
assert.equal(git('status','--porcelain'),'');assert.equal(git('ls-tree','-rz','HEAD'),before);assert.deepEqual(phase(),phaseBefore);
const evidence=rows.flatMap(r=>['stdout.txt','stderr.txt','terminal.json'].map(s=>{const file=r.name+'.'+s,b=fs.readFileSync(out+'/'+file);return{file,bytes:b.length,sha256:hash(b)};}));
save('landed-verification-receipt.json',{classification:'EXACT_LANDED_R11_TREE_AND_HOSTED_CONTEXT_SYNTHETIC_UNIT_SMOKE_NOT_CONSUMER_QUALIFICATION',status:'PASS',acceptedMainSha:head,acceptedMainTree:tree,sourceCandidate:source,reviewedWorkingAndGitBlobsMatched:manifest.entries.length,cleanBeforeAndAfter:true,trackedInventoryUnchanged:true,ownedControlOutputsBefore:phaseBefore,ownedControlOutputsAfter:phase(),commands:rows,evidence,networkWrites:0,consumerInvocations:0,phaseClaims:0,featureCatalog:'NO CHANGE REQUIRED'});
