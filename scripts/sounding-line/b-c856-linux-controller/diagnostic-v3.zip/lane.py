"""Linux-only observer for one fixed C856 diagnostic lane."""
import base64
import hashlib
import json
import os
import selectors
import subprocess
import threading
import time
from pathlib import Path

from boundary import BoundaryError, outer_arguments, process_identity
from observer import bind_application_socket, bind_chromium, local_child, status, wait_pidfds
from receipts import LaneReceipt, MAX_RECORD, json_line, need

MAX_STATUS = 8192
MAX_LANE_SECONDS = 165


class PipeLines:
    def __init__(self, stream):
        self.stream = stream
        self.buffer = bytearray()

    def line(self, deadline):
        with selectors.DefaultSelector() as selector:
            selector.register(self.stream, selectors.EVENT_READ)
            while True:
                end = self.buffer.find(b"\n")
                if end >= 0:
                    line = bytes(self.buffer[:end + 1])
                    del self.buffer[:end + 1]
                    return line
                need(len(self.buffer) <= MAX_RECORD and selector.select(max(0, deadline-time.monotonic())),
                     "OBSERVER_PIPE_DEADLINE")
                data = os.read(self.stream.fileno(), 65536)
                if not data:
                    need(not self.buffer, "INCOMPLETE_OBSERVER_PIPE")
                    return b""
                self.buffer.extend(data)


def namespace_child(launcher):
    text = bytearray()
    fd, reader = launcher
    with selectors.DefaultSelector() as selector:
        selector.register(reader, selectors.EVENT_READ)
        deadline = time.monotonic() + 12
        while selector.select(max(0, deadline-time.monotonic())):
            chunk = os.read(reader, MAX_STATUS - len(text) + 1)
            if not chunk:
                break
            text.extend(chunk)
            need(len(text) <= MAX_STATUS, "OUTER_STATUS_BOUND")
            try:
                pid = json.loads(text)["child-pid"]
            except json.JSONDecodeError:
                continue
            need(type(pid) is int and pid > 1 and fd.poll() is None, "OUTER_PID")
            return pid
    raise BoundaryError("OUTER_READY_DEADLINE")


def send(pipe, value):
    data = json.dumps(value, separators=(",", ":")).encode("ascii") + b"\n"
    pipe.write(data)
    pipe.flush()


def drain_errors(stream, destination, state):
    # Retain original failing setup diagnostics, within a strict byte cap.
    try:
        with destination.open("xb") as output:
            while data := stream.read(65536):
                if output.tell() + len(data) > 1 << 20:
                    state.append("STDERR_BOUND")
                    return
                output.write(data)
    except OSError:
        state.append("STDERR_READ")
    finally:
        stream.close()


def endpoint_payload(endpoint):
    return {key: endpoint[key] for key in ("file", "tcp", "unix", "abstract")}


def run_lane(bundle, destination, selected, media, seed, own, peer, host, chromium_sha256,
             start_barrier, finish_barrier, aggregate, snapshot=False, sentinel_only=False):
    deadline = time.monotonic() + MAX_LANE_SECONDS
    ordinal = selected["ordinal"]
    destination.mkdir(mode=0o700, exist_ok=False)
    receive = None if sentinel_only else LaneReceipt(destination / "originals", selected["contextId"], media, snapshot, aggregate)
    status_read, status_write = os.pipe2(os.O_CLOEXEC)
    release_read, release_write = os.pipe2(os.O_CLOEXEC)
    child = None
    fds = {}
    observed = {}
    controls = {}
    failures = []
    stderr_thread = None
    lines = None
    failed = False
    try:
        child = subprocess.Popen(
            outer_arguments(str(bundle), status_write, release_read),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            close_fds=True, pass_fds=(status_write, release_read), env={"PATH": "/usr/bin", "LANG": "C"},
        )
        os.close(status_write)
        status_write = -1
        os.close(release_read)
        release_read = -1
        stderr_thread = threading.Thread(target=drain_errors, args=(child.stderr, destination/"stderr.original", failures))
        stderr_thread.start()
        outer = namespace_child((child, status_read))
        fds["outer"] = os.pidfd_open(outer)
        observed["outer"] = process_identity(outer, fds["outer"])
        os.write(release_write, b"\1")
        os.close(release_write)
        release_write = -1
        lines = PipeLines(child.stdout)
        send(child.stdin, {"ordinal": ordinal, "snapshot": snapshot, "seed": base64.b64encode(seed).decode("ascii"),
             "sha256": hashlib.sha256(seed).hexdigest(), "own": own, "sentinelOnly": sentinel_only,
             "controls": {"host": endpoint_payload(host), "other": endpoint_payload(peer)}})
        positive = json_line(lines.line(deadline))
        need(positive == {"kind": "peer-positive", "ordinal": ordinal,
             "sha256": hashlib.sha256(own["marker"].encode("ascii")).hexdigest()}, "PEER_POSITIVE")
        start_barrier.wait(timeout=20)
        send(child.stdin, {"start": True})
        for line in iter(lambda: lines.line(deadline), b""):
            record = json_line(line)
            kind = record["kind"]
            if kind == "outer-failure":
                raise BoundaryError(record["code"])
            if kind == "child-ready":
                role = record["role"]
                need(role in ("app", "browser") and role not in observed and not sentinel_only, "BRANCH_IDENTITY")
                pid = local_child(outer, record["localPid"], len(status(outer)["NSpid"].split()))
                fds[role] = os.pidfd_open(pid)
                observed[role] = process_identity(pid, fds[role])
                send(child.stdin, {"release": role})
                if role == "browser":
                    native, renderer, native_fds = bind_chromium(pid, observed[role], chromium_sha256, seconds=20)
                    observed["chromium"], observed["renderer"] = native, renderer
                    fds["chromium"], fds["renderer"] = native_fds
            elif kind == "branch-controls":
                role = record["role"]
                need(role in ("app", "browser") and role not in controls, "BRANCH_CONTROL_IDENTITY")
                controls[role] = record["payload"]
            elif kind == "application-local-http":
                need(record["origin"] == "http://127.0.0.1:32145/" and "app" in observed and "localHttp" not in controls, "PRIVATE_HTTP")
                controls["localHttp"], fds["app-listener"] = bind_application_socket(observed["app"]["pid"], 32145)
            elif kind in ("outer-ready-close", "sentinel-ready-close"):
                need((kind == "sentinel-ready-close") == sentinel_only, "OUTER_CLOSE_IDENTITY")
                finish_barrier.wait(timeout=30)
                send(child.stdin, {"close": True})
                child.stdin.close()
            elif kind == "outer-closed":
                need(record["ordinal"] == ordinal, "OUTER_ORDINAL")
                controls["normalClosure"] = True
            else:
                need(receive is not None, "SENTINEL_RECORD")
                receive.consume(line)
        need(child.wait(timeout=max(.1, deadline-time.monotonic())) == 0, "OUTER_EXIT")
        wait_pidfds(fds.values(), 2500)
        stderr_thread.join(2)
        need(not stderr_thread.is_alive() and not failures, "STDERR_TEARDOWN")
        if receive is not None:
            need(set(controls) == {"app", "browser", "localHttp", "normalClosure"} and
                 set(observed) == {"outer", "app", "browser", "chromium", "renderer"}, "INCOMPLETE_LIVE_EVIDENCE")
        return {"processes": observed, "controls": controls, "allPidfdsExited": True,
                "allPipesClosed": True, "receipt": receive.finish() if receive else None,
                "root": str(destination / "originals"), "contextId": selected["contextId"],
                "seedSha256": hashlib.sha256(seed).hexdigest()}
    except BaseException:
        failed = True
        start_barrier.abort()
        finish_barrier.abort()
        raise
    finally:
        if child is not None:
            if child.poll() is None:
                child.kill()
            launcher_exit = None
            cleanup_error = None
            try:
                launcher_exit = child.wait(timeout=5)

            except (OSError, subprocess.TimeoutExpired, BoundaryError) as error:
                cleanup_error = type(error).__name__ + ":" + str(error)[:160]
            if failed:
                observed_error = None
                try:
                    wait_pidfds(fds.values(), 2500)
                except (OSError, BoundaryError) as error:
                    observed_error = type(error).__name__ + ":" + str(error)[:160]
                with (destination / "failure-cleanup.json").open("xb") as file:
                    file.write(json.dumps({"launcherExitCode": launcher_exit,
                        "observedPids": {role: item["pid"] for role, item in observed.items()},
                        "trackedDescriptors": sorted(fds), "allObservedPidfdsExited": bool(fds) and observed_error is None,
                        "closureScope": "OBSERVED_PIDFDS_ONLY", "descendantClosureProved": False,
                        "observedCleanupError": observed_error,
                        "cleanupError": cleanup_error}, sort_keys=True).encode("ascii") + b"\n")
            for stream in (child.stdin, child.stdout):
                stream.close()
            if stderr_thread is not None:
                stderr_thread.join(2)
        for fd in (status_read, status_write, release_read, release_write, *fds.values()):
            if fd >= 0:
                os.close(fd)
