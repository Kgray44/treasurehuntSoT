import unittest
from boundary import (BoundaryError, browser_arguments, app_arguments, outer_arguments,
                      verify_observation, NAMESPACES)


def ids(prefix):
    return {name: f"{name}:[{prefix+i}]" for i, name in enumerate(NAMESPACES)}


def process(prefix, pid, *, seccomp=0):
    return {"pid": pid, "startTicks": pid+10, "namespaces": ids(prefix),
            "noNewPrivs": True, "capEff": 0, "seccomp": seccomp}


def lane(prefix):
    outer, app, browser, renderer = [process(prefix+10*i, prefix+i+1) for i in range(4)]
    app["namespaces"]["net"] = browser["namespaces"]["net"] = outer["namespaces"]["net"]
    renderer["seccomp"] = 2
    chromium = {**browser, "pid": prefix + 5, "startTicks": prefix + 15}
    return {"outer": outer, "app": app, "browser": browser, "chromium": chromium, "renderer": renderer,
            "browserExecutableVerified": True, "rendererExecutableVerified": True,
            "rendererDescendantVerified": True, "nativeFlagsVerified": True,
            "closedPids": [item["pid"] for item in (outer, app, browser, chromium, renderer)],
            "fileDenials": ["app:host", "app:other", "browser:host", "browser:other"],
            "socketDenials": [f"{branch}:{target}:{kind}" for branch in ("app", "browser")
                              for target in ("host", "other") for kind in ("tcp", "unix", "abstract")],
            "authoredPageAndListenerVerified": True, "hostControlsPositive": True, "appNewUsernsDenied": True,
            "browserPrivateProcVerified": True, "browserMapWritesVerified": True,
            "hostPolicyUnchanged": True, "loopbackOnly": True, "closedStreams": True}


class BoundaryTests(unittest.TestCase):
    def test_args_keep_nested_namespace_lock_on_app_only(self):
        outer = outer_arguments("/bundle", 3, 4)
        app = app_arguments(3, 4)
        browser = browser_arguments(3, 4)
        self.assertIn("--unshare-net", outer)
        self.assertNotIn("--share-net", outer)
        self.assertIn("--disable-userns", app)
        self.assertNotIn("--disable-userns", browser)
        for child in (app, browser):
            self.assertNotIn("--unshare-net", child)
            self.assertIn("--unshare-pid", child)
            self.assertIn("--unshare-user", child)
        self.assertNotIn("/proc", [browser[i+1] for i,x in enumerate(browser) if x == "--remount-ro"])

    def test_rejects_shared_network_missing_renderer_and_partial_cleanup(self):
        host, a, b = ids(999), lane(100), lane(200)
        verify_observation(host, (a, b))
        b["browser"]["namespaces"]["net"] = a["outer"]["namespaces"]["net"]
        with self.assertRaises(BoundaryError):
            verify_observation(host, (a, b))
        b = lane(200)
        b["chromium"]["capEff"] = 1
        with self.assertRaises(BoundaryError):
            verify_observation(host, (a, b))
        b = lane(200)
        b["renderer"]["seccomp"] = 0
        with self.assertRaises(BoundaryError):
            verify_observation(host, (a, b))
        b = lane(200)
        b["closedPids"].pop()
        with self.assertRaises(BoundaryError):
            verify_observation(host, (a, b))

    def test_rejects_wrong_lane_socket_and_incomplete_private_proc_checks(self):
        for mutate in (lambda x: x["socketDenials"].pop(), lambda x: x.update(browserPrivateProcVerified=False),
                       lambda x: x.update(browserMapWritesVerified=False), lambda x: x.update(appNewUsernsDenied=False)):
            a, b = lane(100), lane(200)
            mutate(b)
            with self.assertRaises(BoundaryError):
                verify_observation(ids(999), (a, b))
