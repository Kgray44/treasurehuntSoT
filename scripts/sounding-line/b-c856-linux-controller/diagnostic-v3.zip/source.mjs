import { createHash } from "node:crypto";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL } from "node:url";

export const SOURCE = "31181b7b94816b0cf22c79bcebbaecb24e01eec9";
export const TREE = "1f92226da882098af1fdd6d42a3e43927f6ad676";
export const PLAN_DIGEST = "351babed4eea7b07decfa6fcaba6dcb2e49e033e13115788f3c845461984f317";
export const CONTRACT_DIGEST = "98fbeda9cd33e7a771a42a171e33ae23dff549f00ba5943df130d905769b982e";
export const COVERAGE = "9f4ea7107544a57601ed56fffb58be154f38b446a2c16b843a92f96b0ce5a273";
export const CAPTURE_SHA = "5c1696aa21364352ff764175a1959eac21481f4aecd9b1ba7d85cd01db10b2c3";
export const CONTRACT_PATH = "testing/contracts.json";
export const CONTRACT_SHA = "42ffffc2c14dab3e22ab2990e6f70e092afb119b33b5fe071d7b300aeda049b4";
export const DIAGNOSTIC_CONTEXT_NAMESPACE = 2147483647;
const LAUNCH = "await chromium.launch({ headless: true })";
export const sha256 = (data) => createHash("sha256").update(data).digest("hex");

export function sandboxedCaptureBytes(source) {
  assert.equal(sha256(source), CAPTURE_SHA, "CAPTURE_SOURCE_IDENTITY");
  const text = new TextDecoder("utf-8", { fatal: true }).decode(source);
  assert.equal(text.split(LAUNCH).length, 2, "EXACT_CHROMIUM_LAUNCH");
  return Buffer.from(text.replace(LAUNCH, "await chromium.launch({ headless: true, chromiumSandbox: true })"));
}

export async function derivePlan(root) {
  const git = (...argv) => execFileSync("git", ["-c", "protocol.allow=never", ...argv], {
    cwd: root, timeout: 10000, maxBuffer: 2 << 20,
    env: { ...process.env, GIT_NO_LAZY_FETCH: "1", GIT_NO_REPLACE_OBJECTS: "1", GIT_OPTIONAL_LOCKS: "0" },
  });
  assert.equal(git("rev-parse", "HEAD").toString().trim(), SOURCE);
  assert.equal(git("rev-parse", "HEAD^{tree}").toString().trim(), TREE);
  git("diff", "--quiet", "HEAD", "--");
  assert.equal(sha256(git("show", SOURCE + ":" + CONTRACT_PATH)), CONTRACT_SHA);
  const module = (name) => import(pathToFileURL(resolve(root, "scripts/sounding-line", name)).href);
  const [{ activationPlan }, { shadowCaptureContextSchedule }, { artifactLogicalKey }] = await Promise.all([
    module("experience-prepare.mjs"), module("experience-browser.mjs"), module("artifact-evidence-registry.mjs"),
  ]);
  const plan = {
    ...activationPlan({ root, baseSha: SOURCE, candidateSha: SOURCE }),
    // The shadow journal requires a positive slot. This private slot does not
    // identify a provider pull request and is never published as an identity.
    prNumber: DIAGNOSTIC_CONTEXT_NAMESPACE,
  };
  assert.equal(plan.sourceDigest, PLAN_DIGEST);
  assert.equal(plan.contractDigest, CONTRACT_DIGEST);
  assert.deepEqual(plan.contracts.map((contract) => contract.id), ["homeport.transition.auth-routes"]);
  assert(!plan.paired && !plan.pairedOnly && !plan.exception && !plan.localProof);
  const contexts = shadowCaptureContextSchedule(plan);
  assert.equal(contexts.length, 2);
  const obligations = contexts.flatMap(({ context, contextId }) => {
    assert.equal(context.role, "ANONYMOUS");
    const journey = plan.contracts[0].experience.journeys.find(({ id }) => id === context.journeyId);
    assert(journey && journey.steps.every((step) => !Object.hasOwn(step, "when") && !Object.hasOwn(step, "devices")));
    const records = journey.steps.flatMap(({ state }, captureIndex) =>
      state ? [{ ...context, type: "screenshot", state, captureIndex }] : []);
    for (const type of ["recording", "trace", "accessibility", "cleanup", "journey"])
      records.push({ ...context, type, state: "CONTEXT_CLOSED", captureIndex: null });
    return records.map((logical) => ({ contextId, logical, key: artifactLogicalKey(logical) }));
  });
  const keys = obligations.map(({ key }) => key).sort();
  assert.equal(keys.length, 16);
  assert.equal(new Set(keys).size, 16);
  assert.equal(sha256(JSON.stringify(keys)), COVERAGE);
  return { plan, contexts, obligations };
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  assert.equal(process.argv.length, 3);
  const root = resolve(process.argv[2]);
  const capture = readFileSync(resolve(root, "scripts/sounding-line/experience-browser.mjs"));
  const copy = sandboxedCaptureBytes(capture);
  const prepared = await derivePlan(root);
  process.stdout.write(JSON.stringify({ ...prepared, sandboxedCaptureSha256: sha256(copy) }) + "\n");
}
