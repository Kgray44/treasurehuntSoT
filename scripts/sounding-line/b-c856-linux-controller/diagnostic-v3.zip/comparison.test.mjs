import assert from "node:assert/strict";
import test from "node:test";
import { hash, verifyLanes } from "./comparison.mjs";
import { sandboxedCaptureBytes, derivePlan } from "./source.mjs";

test("rejects substituted Chromium launch source", () => {
  assert.throws(() => sandboxedCaptureBytes(Buffer.from("await chromium.launch({ headless: true })")),
    /CAPTURE_SOURCE_IDENTITY/);
});

test("each authored obligation, rehash, original prefix, and observed semantics are required", () => {
  const obligations = Array.from({ length: 16 }, (_, i) => ({
    key: "key" + i, contextId: "ctx" + Math.floor(i/8),
    logical: { type: i%8 < 3 ? "screenshot" : ["recording","trace","journey","accessibility","cleanup"][i%8 - 3] },
  }));
  const records = obligations.map(({ key, contextId, logical }) => {
    const original = Buffer.from(key);
    return { key, contextId, type: logical.type, original, sha256: hash(original), semantic: { observed: key } };
  });
  const prefix = records.slice(0, 8).map(({ key, sha256 }) => ({ key, sha256 }));
  assert.equal(verifyLanes(obligations, records, records, prefix).obligations, 16);
  for (const fault of [
    records.slice(1), [...records.slice(0, 15), records[0]],
    [{ ...records[0], contextId: "ctx1" }, ...records.slice(1)],
    [{ ...records[0], original: Buffer.from("altered") }, ...records.slice(1)],
    [{ ...records[0], semantic: undefined }, ...records.slice(1)],
    [{ ...records[0], semantic: { observed: "drift" } }, ...records.slice(1)],
  ]) assert.throws(() => verifyLanes(obligations, records, fault, prefix));
  assert.throws(() => verifyLanes(obligations, records, records, prefix.slice(1)));
});
