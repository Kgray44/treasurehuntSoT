import hashlib
import io
import tarfile
import tempfile
import unittest
from pathlib import Path

from package import PackageError, exact_record, member_bytes, publish_noreplace, verify_installed, package_stanzas


def elf():
    return b"\x7fELF\x02\x01\x01" + bytes(11) + b"\x3e\x00" + bytes(110)


class PackageTests(unittest.TestCase):
    def test_duplicate_or_substituted_package_record_fails(self):
        record = {
            "Package": "bubblewrap", "Version": "0.12.0-1", "Architecture": "amd64",
            "Filename": "pool/main/b/bubblewrap/bubblewrap_0.12.0-1_amd64.deb",
            "Size": "51272",
            "SHA512": "f4e2c7e8944e22ea0d49ad88fdba695a78dd5793524fdbf8cccdf8f0984c0b3e13c27812e92664d2f0a71cd09c4121e470468c962da1c644e9566e2082aaae6a"
        }
        self.assertEqual(exact_record([record]), record)
        for records in ([record, record], [{**record, "SHA512": "0" * 128}], [{**record, "Filename": "../bwrap"}]):
            with self.assertRaises(PackageError):
                exact_record(records)

    def test_moving_pocket_does_not_skip_reordered_or_crlf_stanzas(self):
        data = b"Version: 0.13.0-1\r\nPackage: bubblewrap\r\nArchitecture: amd64\r\n\r\nPackage: other\r\n"
        self.assertEqual(package_stanzas(data)[0]["Version"], "0.13.0-1")

    def test_extracts_only_single_plain_regular_exact_member(self):
        for names in (["./usr/bin/bwrap"], ["./usr/bin/bwrap", "usr/bin/bwrap"],
                      ["./usr/bin/bwrap", "./usr/bin/bwrap"]):
            out = io.BytesIO()
            with tarfile.open(fileobj=out, mode="w") as archive:
                for name in names:
                    info = tarfile.TarInfo(name)
                    info.uid, info.gid, info.mode, info.size = 0, 0, 0o755, len(elf())
                    archive.addfile(info, io.BytesIO(elf()))
            if len(names) == 1:
                self.assertEqual(member_bytes(out.getvalue()), elf())
            else:
                with self.assertRaises(PackageError):
                    member_bytes(out.getvalue())

    @unittest.skipUnless(__import__("sys").platform == "linux", "Linux mode and link semantics")
    def test_no_replace_refuses_existing_different_bytes(self):
        import os
        with tempfile.TemporaryDirectory() as root:
            p = Path(root)
            (p / "bwrap").write_bytes(b"pre-existing")
            fd = os.open(root, os.O_DIRECTORY)
            try:
                with self.assertRaises(PackageError):
                    publish_noreplace(fd, elf(), uid=os.getuid())
                self.assertEqual((p / "bwrap").read_bytes(), b"pre-existing")
                self.assertEqual(sorted(x.name for x in p.iterdir()), ["bwrap"])
                (p / "bwrap").unlink()
                publish_noreplace(fd, elf(), uid=os.getuid())
                self.assertEqual(verify_installed(fd, elf(), uid=os.getuid()), hashlib.sha256(elf()).hexdigest())
            finally:
                os.close(fd)


if __name__ == "__main__":
    unittest.main()
