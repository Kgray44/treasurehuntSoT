import unittest
from media import MediaError, RGB, ordered_witness


class MediaTests(unittest.TestCase):
    def test_requires_all_three_recorded_states_in_order(self):
        frames = [bytes([intensity]) * RGB for intensity in (10, 70, 200)]
        self.assertEqual(ordered_witness(frames, frames), [0, 1, 2])
        for altered in (frames[::-1], [frames[0]] * 3, frames[:-1]):
            with self.assertRaises(MediaError):
                ordered_witness(altered, frames)
