"""Fixed C856 Bubblewrap admission. Importing this module performs no IO."""
import hashlib
import io
import lzma
import os
import re
import secrets
import selectors
import time
import stat
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path

ARCHIVE = "https://archive.ubuntu.com/ubuntu/"
SECURITY_ARCHIVE = "https://security.ubuntu.com/ubuntu/"
POCKETS = ("stonking", "stonking-security", "stonking-updates")
INDEX = "main/binary-amd64/Packages.xz"
INDEX_SIZE = 992688
INDEX_HASH = "1180e265fc90a5ca3caa782baf3f555baad1bc878bb3787020498698ff68e4c0915e2f702ff73573c7333e71f7271a3169df13717a3b64e76b361f465872e44d"
VERSION = "0.12.0-1"
PACKAGE = f"pool/main/b/bubblewrap/bubblewrap_{VERSION}_amd64.deb"
PACKAGE_SIZE = 51272
PACKAGE_HASH = "f4e2c7e8944e22ea0d49ad88fdba695a78dd5793524fdbf8cccdf8f0984c0b3e13c27812e92664d2f0a71cd09c4121e470468c962da1c644e9566e2082aaae6a"
KEYRING = "/usr/share/keyrings/ubuntu-archive-keyring.gpg"
MIB = 1 << 20
CLEAN_ENV = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}


class PackageError(ValueError):
    pass


def need(condition, code):
    if not condition:
        raise PackageError(code)


def sha512(data):
    return hashlib.sha512(data).hexdigest()


def fields(data):
    result, key = {}, None
    for line in data.splitlines():
        if not line:
            continue
        if line.startswith((" ", "\t")):
            need(key is not None, "MALFORMED_CONTINUATION")
            result[key] += "\n" + line.strip()
            continue
        key, sep, value = line.partition(":")
        need(sep and re.fullmatch(r"[A-Za-z0-9-]+", key) and key not in result, "MALFORMED_FIELD")
        result[key] = value.strip()
    return result


def signed_release(inrelease):
    need(sys.platform == "linux" and 0 < len(inrelease) <= 2*MIB, "RELEASE_SCOPE")
    trusted = Path(KEYRING)
    need(trusted.resolve(strict=True) == trusted, "ARCHIVE_KEYRING_PATH")
    for component in (trusted, *trusted.parents):
        record = component.lstat()
        need(record.st_uid == 0 and not record.st_mode & 0o022, "ARCHIVE_KEYRING_OWNER")
    need(stat.S_ISREG(trusted.stat().st_mode), "ARCHIVE_KEYRING_TYPE")
    with tempfile.TemporaryDirectory(prefix="c856-gpgv-") as home:
        process = subprocess.run(
            ["/usr/bin/gpgv", "--homedir", home, "--keyring", KEYRING, "--output", "-"],
            input=inrelease, capture_output=True, timeout=15, env=CLEAN_ENV, check=False,
        )
    need(process.returncode == 0 and 0 < len(process.stdout) <= 2*MIB, "RELEASE_SIGNATURE")
    return fields(process.stdout.decode("utf-8", errors="strict"))


def package_records(release, compressed, pocket, now):
    need(pocket in POCKETS and 0 < len(compressed) <= 8*MIB, "INDEX_BOUND")
    need([release.get(k) for k in ("Origin", "Label", "Suite", "Codename", "Version")] ==
         ["Ubuntu", "Ubuntu", pocket, "stonking", "26.10"], "RELEASE_SCOPE")
    need("amd64" in release.get("Architectures", "").split() and
         "main" in release.get("Components", "").split(), "RELEASE_ARCHITECTURE")
    date = parsedate_to_datetime(release.get("Date"))
    need(date.tzinfo is not None and date <= now + timedelta(minutes=10), "RELEASE_FUTURE")
    if "Valid-Until" in release:
        expiry = parsedate_to_datetime(release["Valid-Until"])
        need(expiry.tzinfo is not None and now <= expiry, "RELEASE_EXPIRED")
    if pocket == POCKETS[0]:
        need(date == datetime(2026, 10, 15, 12, 18, 34, tzinfo=timezone.utc) and
             len(compressed) == INDEX_SIZE and sha512(compressed) == INDEX_HASH, "BASE_INDEX_PIN")
    else:
        need(now - date <= timedelta(days=7), "MOVING_INDEX_AGE")
    actual = [sha512(compressed), str(len(compressed)), INDEX]
    rows = [parts for line in release.get("SHA512", "").splitlines()
            if (parts := line.split()) and parts[-1] == INDEX]
    need(rows == [actual], "INDEX_SHA512")
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=64*MIB)
    decoded = decoder.decompress(compressed, max_length=32*MIB)
    need(decoder.eof and not decoder.unused_data and len(decoded) < 32*MIB, "INDEX_EXPANSION")
    return package_stanzas(decoded)


def exact_record(records):
    need(len(records) == 1, "EXACT_PACKAGE_STANZA")
    expected = {
        "Package": "bubblewrap", "Version": VERSION, "Architecture": "amd64",
        "Filename": PACKAGE, "Size": str(PACKAGE_SIZE), "SHA512": PACKAGE_HASH,
    }
    record = records[0]
    need(all(record.get(k) == value for k, value in expected.items()), "EXACT_PACKAGE_PIN")
    return record


def verify_inputs(metadata, deb, now):
    need(set(metadata) == set(POCKETS), "ARCHIVE_INPUTS")
    for pocket in POCKETS:
        inrelease, index = metadata[pocket]
        records = package_records(signed_release(inrelease), index, pocket, now)
        if pocket == POCKETS[0]:
            exact_record(records)
        else:
            # A new applicable package requires new source review and pin.
            need(not records, "MOVING_PACKAGE_CHANGED")
    need(len(deb) == PACKAGE_SIZE and sha512(deb) == PACKAGE_HASH, "PACKAGE_SHA512")


def member_bytes(tar):
    need(0 < len(tar) <= 8*MIB, "PACKAGE_EXPANSION")
    with tarfile.open(fileobj=io.BytesIO(tar), mode="r:") as archive:
        selected = [item for item in archive if item.name.lstrip("./") == "usr/bin/bwrap"]
        need(len(selected) == 1, "BINARY_ARCHIVE_MEMBER")
        info = selected[0]
        need(info.name in ("./usr/bin/bwrap", "usr/bin/bwrap") and info.isreg() and
             info.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not info.pax_headers and
             info.uid == 0 and info.gid == 0 and info.mode == 0o755 and
             64 <= info.size <= 512*1024, "BINARY_ARCHIVE_METADATA")
        stream = archive.extractfile(info)
        need(stream is not None, "BINARY_ARCHIVE_MEMBER")
        executable = stream.read()
    need(len(executable) == info.size and executable[:7] == b"\x7fELF\x02\x01\x01" and
         executable[18:20] == b"\x3e\x00", "BINARY_ELF_AMD64")
    return executable


def package_stanzas(decoded):
    entries = [fields(record) for record in re.split(r"\r?\n\r?\n", decoded.decode("utf-8", errors="strict"))
               if record.strip()]
    return [entry for entry in entries if entry.get("Package") == "bubblewrap"]


def file_identity(record):
    return (record.st_dev, record.st_ino, record.st_mode, record.st_uid, record.st_gid,
            record.st_nlink, record.st_size, record.st_mtime_ns, record.st_ctime_ns)


def bounded_tar(deb):
    # Fixed signed bytes are written once and handed to dpkg-deb on stdin.
    # Bound both child streams before appending any bytes to a buffer.
    with tempfile.TemporaryFile() as input_file:
        input_file.write(deb)
        input_file.seek(0)
        child = subprocess.Popen(
            ["/usr/bin/dpkg-deb", "--fsys-tarfile", "-"], stdin=input_file,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=CLEAN_ENV,
        )
        outputs = {"stdout": bytearray(), "stderr": bytearray()}
        try:
            with selectors.DefaultSelector() as selector:
                for name in outputs:
                    selector.register(getattr(child, name), selectors.EVENT_READ, name)
                deadline = time.monotonic() + 15
                while selector.get_map():
                    events = selector.select(max(0, deadline-time.monotonic()))
                    need(events and time.monotonic() <= deadline, "PACKAGE_EXTRACT_DEADLINE")
                    for event, _ in events:
                        buffer = outputs[event.data]
                        bound = 8*MIB if event.data == "stdout" else 65536
                        block = os.read(event.fd, min(65536, bound - len(buffer) + 1))
                        if not block:
                            selector.unregister(event.fileobj)
                            continue
                        need(len(buffer) + len(block) <= bound, "PACKAGE_EXPANSION")
                        buffer.extend(block)
            need(child.wait(timeout=max(.1, deadline-time.monotonic())) == 0, "PACKAGE_EXTRACT")
            return bytes(outputs["stdout"])
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=2)
            child.stdout.close()
            child.stderr.close()



def verified_package_member(deb):
    # This also authenticates the root-side handoff by its separately reviewed pin.
    need(sys.platform == "linux" and len(deb) == PACKAGE_SIZE and sha512(deb) == PACKAGE_HASH, "PACKAGE_SHA512")
    return member_bytes(bounded_tar(deb))


def verify_installed(directory, executable, uid=0):
    fd = os.open("bwrap", os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
    try:
        st = os.fstat(fd)
        need(stat.S_ISREG(st.st_mode) and stat.S_IMODE(st.st_mode) == 0o755 and
             st.st_uid == uid and st.st_gid == (0 if uid == 0 else os.getgid()) and
             st.st_nlink == 1 and st.st_size == len(executable) and
             "security.capability" not in os.listxattr(fd), "INSTALLED_IDENTITY")
        with os.fdopen(os.dup(fd), "rb") as stream:
            actual = stream.read(len(executable) + 1)
        observed = os.stat("bwrap", dir_fd=directory, follow_symlinks=False)
        need(actual == executable and file_identity(observed) == file_identity(st)
             and file_identity(os.fstat(fd)) == file_identity(st), "INSTALLED_BYTES")
        return hashlib.sha256(actual).hexdigest()
    finally:
        os.close(fd)


def publish_noreplace(directory, executable, uid=0):
    # Link publishes atomically and cannot replace a different directory entry.
    stage = ".sounding-line-bwrap-" + secrets.token_hex(16)
    fd = os.open(stage, os.O_CREAT | os.O_EXCL | os.O_RDWR | os.O_NOFOLLOW, 0o600, dir_fd=directory)
    try:
        with os.fdopen(fd, "w+b") as stream:
            stream.write(executable)
            stream.flush()
            stream.seek(0)
            need(stream.read(len(executable) + 1) == executable, "STAGED_BYTES")
            os.fchmod(stream.fileno(), 0o755)
            os.fsync(stream.fileno())
            try:
                os.link(stage, "bwrap", src_dir_fd=directory, dst_dir_fd=directory, follow_symlinks=False)
            except FileExistsError:
                return verify_installed(directory, executable, uid)
    finally:
        os.unlink(stage, dir_fd=directory)
    os.fsync(directory)
    return verify_installed(directory, executable, uid)


def stage_verified_binary(deb):
    need(sys.platform == "linux" and os.geteuid() == 0, "STAGE_REQUIRES_ROOT")
    executable = verified_package_member(deb)
    directory = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for name in ("usr", "bin"):
            parent = directory
            directory = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent)
            mode = os.fstat(directory)
            need(mode.st_uid == 0 and mode.st_gid == 0 and not mode.st_mode & 0o022, "CANONICAL_PARENT")
        return publish_noreplace(directory, executable)
    finally:
        os.close(directory)


def dependency_receipt(executable):
    """Resolve the already authenticated binary using only the runner loader."""
    loader = Path("/lib64/ld-linux-x86-64.so.2").resolve(strict=True)
    need(loader.name == "ld-linux-x86-64.so.2" and loader.parent in (
        Path("/usr/lib/x86_64-linux-gnu"), Path("/lib/x86_64-linux-gnu")), "NATIVE_LOADER")
    for member in (loader, *loader.parents):
        st = member.lstat()
        need(st.st_uid == 0 and not st.st_mode & 0o022, "NATIVE_LOADER_OWNER")
    result = subprocess.run(
        [str(loader), "--list", "/usr/bin/bwrap"], capture_output=True,
        env=CLEAN_ENV, timeout=8, check=False,
    )
    need(result.returncode == 0 and 0 < len(result.stdout) <= 32768 and not result.stderr, "BINARY_ABI")
    libraries = {}
    for line in result.stdout.decode("ascii").splitlines():
        line = line.strip()
        if line.startswith("linux-vdso.so.1 ") or line.startswith(str(loader)) or line.startswith("/lib64/ld-linux"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.+-]+) => (/[^ ]+) \(0x[0-9a-f]+\)", line)
        need(match is not None, "BINARY_LIBRARY_LINE")
        name, location = match.groups()
        file = Path(location).resolve(strict=True)
        need(name not in libraries and file.parent == loader.parent, "BINARY_LIBRARY_PATH")
        for member in (file, *file.parents):
            inode = member.lstat()
            need(inode.st_uid == 0 and not inode.st_mode & 0o022, "BINARY_LIBRARY_OWNER")
        with file.open("rb") as stream:
            prior = os.fstat(stream.fileno())
            need(stat.S_ISREG(prior.st_mode) and 0 < prior.st_size <= 16*MIB, "BINARY_LIBRARY_SIZE")
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
            need(file_identity(prior) == file_identity(os.fstat(stream.fileno())) ==
                 file_identity(file.stat()), "BINARY_LIBRARY_CHANGED")
        libraries[name] = digest
    need({"libcap.so.2", "libselinux.so.1", "libc.so.6"} <= set(libraries), "BINARY_LIBRARIES_MISSING")
    with loader.open("rb") as stream:
        loader_hash = hashlib.file_digest(stream, "sha256").hexdigest()
    directory = os.open("/usr/bin", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        verify_installed(directory, executable)
    finally:
        os.close(directory)
    return {"loaderSha256": loader_hash, "libraries": libraries}



if __name__ == "__main__":
    # Future operator invokes a separately approved, root-owned copy of this
    # file with Python isolated mode. The wire carries only the pinned deb.
    need(sys.argv[1:] == ["--stage-fixed-c856"], "FIXED_STAGE_COMMAND")
    data = sys.stdin.buffer.read(PACKAGE_SIZE + 1)
    print(stage_verified_binary(data))

