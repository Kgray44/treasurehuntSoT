"""Bounded host-side comparison of original Chromium traces and recordings."""
import io
import json
import os
import re
import selectors
import subprocess
import time
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

TRACE_MAX = 24 << 20
TRACE_TOTAL = 96 << 20
TRACE_MEMBERS = 2048
WIDTH = 64
HEIGHT = 36
RGB = WIDTH * HEIGHT * 3
MAX_VIDEO_FRAMES = 300
TOOLS = {"ffmpeg": "/usr/bin/ffmpeg", "ffprobe": "/usr/bin/ffprobe"}
ENV = {"PATH": "/usr/bin", "LANG": "C", "LC_ALL": "C"}


class MediaError(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise MediaError(code)


def trace_semantics(data):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        info = archive.infolist()
        paths = [item.filename for item in info]
        need(0 < len(info) <= TRACE_MEMBERS and len(paths) == len(set(paths)) and
             all(not path.startswith("/") and "\\" not in path and ".." not in path.split("/") for path in paths) and
             sum(item.file_size for item in info) <= TRACE_TOTAL, "TRACE_ARCHIVE")
        candidates = [item for item in info if re.fullmatch(r"(?:[0-9]+-)?trace\.trace", item.filename)]
        need(len(candidates) == 1 and 0 < candidates[0].file_size <= TRACE_MAX, "TRACE_STREAM")
        with archive.open(candidates[0]) as source:
            trace = source.read(TRACE_MAX + 1)
        need(len(trace) == candidates[0].file_size, "TRACE_LENGTH")
    engine = []
    calls = {}
    outcomes = set()
    ordered = []
    for line in trace.splitlines():
        need(0 < len(line) <= 2 << 20, "TRACE_EVENT_BOUND")
        event = json.loads(line)
        typ = event.get("type")
        if typ == "context-options":
            engine.append(event.get("browserName"))
        elif typ == "before":
            call = event.get("callId")
            need(isinstance(call, str) and call not in calls and len(calls) < 8192, "TRACE_CALL")
            method = event.get("method")
            params = event.get("params") or {}
            calls[call] = (method, params)
            if method in ("click", "goto", "waitForSelector", "screenshot", "press"):
                selected = {name: params[name] for name in ("selector", "key", "state", "strict") if name in params}
                if "url" in params:
                    url = urlsplit(params["url"])
                    need(not url.netloc or (url.scheme == "http" and url.netloc == "127.0.0.1:32145"),
                         "TRACE_ORIGIN")
                    selected["url"] = url.path + ("?" + url.query if url.query else "")
                ordered.append([event.get("class"), method, selected])
        elif typ == "after":
            call = event.get("callId")
            need(call in calls and call not in outcomes, "TRACE_COMPLETION")
            # Browser probes may intentionally time out. Keep error kind for
            # relevant navigation and input operations so drift is visible.
            outcomes.add(call)
            method, params = calls[call]
            if event.get("error") and method in ("click", "goto", "screenshot", "press"):
                raise MediaError("TRACE_RELEVANT_ACTION_FAILED")
    need(engine == ["chromium"] and bool(ordered), "TRACE_ENGINE")
    click_selectors = [entry[2].get("selector", "") for entry in ordered if entry[1] == "click"]
    for label in ("Account", "Sign In", "Forgot Password", "Return to Sign In"):
        need(any(f'name="{label}"' in selector for selector in click_selectors), "TRACE_AUTHORED_ACTION")
    need(sum(entry[1] == "screenshot" for entry in ordered) == 3, "TRACE_AUTHORED_SCREENSHOTS")
    return ordered


def media_tool(tool, flags, data, bound, timeout):
    path = Path(TOOLS[tool])
    st = path.stat()
    need(path.resolve(strict=True) == path and st.st_uid == 0 and not st.st_mode & 0o7022, "MEDIA_TOOL_IDENTITY")
    # Keep input in a bounded anonymous descriptor. Drain and cap both child
    # streams while they are produced, including error output.
    fd = os.memfd_create("c856-media", os.MFD_CLOEXEC)
    with os.fdopen(fd, "w+b") as input_file:
        need(0 < len(data) <= 32 << 20, "MEDIA_INPUT_BOUND")
        input_file.write(data)
        input_file.seek(0)
        child = subprocess.Popen([str(path), *flags], stdin=input_file, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, env=ENV)
        output = bytearray()
        errors = bytearray()
        deadline = time.monotonic() + timeout
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout, selectors.EVENT_READ, (output, bound))
                selector.register(child.stderr, selectors.EVENT_READ, (errors, 65536))
                while selector.get_map():
                    ready = selector.select(max(0, deadline-time.monotonic()))
                    need(ready and time.monotonic() <= deadline, "MEDIA_TOOL_DEADLINE")
                    for key, _ in ready:
                        buffer, maximum = key.data
                        block = os.read(key.fd, min(65536, maximum - len(buffer) + 1))
                        if not block:
                            selector.unregister(key.fileobj)
                            continue
                        need(len(buffer) + len(block) <= maximum, "MEDIA_OUTPUT_BOUND")
                        buffer.extend(block)
            need(child.wait(timeout=max(.1, deadline-time.monotonic())) == 0 and output, "MEDIA_TOOL_FAILED")
            return bytes(output)
        finally:
            if child.poll() is None:
                child.kill()
                child.wait(timeout=2)
            child.stdout.close()
            child.stderr.close()



def probe_recording(data, viewport):
    result = media_tool("ffprobe", [
        "-v", "error", "-protocol_whitelist", "pipe", "-show_entries",
        "stream=codec_name,codec_type,width,height:format=format_name", "-of", "json", "pipe:0",
    ], data, 32768, 10)
    fields = json.loads(result)
    need(len(fields.get("streams", [])) == 1 and "webm" in fields["format"]["format_name"].split(","),
         "RECORDING_FORMAT")
    stream = fields["streams"][0]
    scale = min(1.0, 800 / max(viewport))
    video_size = tuple(int(value * scale) & ~1 for value in viewport)
    need(stream["codec_type"] == "video" and stream["codec_name"] in ("vp8", "vp9") and
         (stream["width"], stream["height"]) == video_size, "RECORDING_VIEWPORT")
    return {"format": "webm", "codec": stream["codec_name"], "viewport": list(viewport)}


def pixels(data, recording):
    frame_cap = MAX_VIDEO_FRAMES + 1 if recording else 1
    filters = ("fps=5," if recording else "") + f"scale={WIDTH}:{HEIGHT}:flags=area,format=rgb24"
    decoded = media_tool("ffmpeg", [
        "-v", "error", "-threads", "1", "-filter_threads", "1", "-max_alloc", str(64 << 20),
        "-protocol_whitelist", "pipe", "-i", "pipe:0", "-map", "0:v:0", "-an",
        "-vf", filters, "-frames:v", str(frame_cap), "-f", "rawvideo", "pipe:1",
    ], data, RGB * frame_cap, 15)
    need(len(decoded) % RGB == 0 and 0 < len(decoded) // RGB < MAX_VIDEO_FRAMES + 1, "FRAME_BOUND")
    return [decoded[offset:offset + RGB] for offset in range(0, len(decoded), RGB)]


def ordered_witness(frames, screenshots):
    """Require all three independently decoded screenshot states in order."""
    need(len(screenshots) == 3 and all(len(item) == RGB for item in screenshots) and
         3 <= len(frames) <= MAX_VIDEO_FRAMES and all(len(item) == RGB for item in frames), "FRAME_DIMENSIONS")
    cursor = 0
    matches = []
    for screenshot in screenshots:
        for index in range(cursor, len(frames)):
            distance = sum(abs(a - b) for a, b in zip(frames[index], screenshot))
            if distance <= 6 * RGB:
                matches.append(index)
                cursor = index + 1
                break
        else:
            raise MediaError("RECORDING_STATE_WITNESS_MISSING")
    return matches
