import base64
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from receipts import LaneReceipt, ReceiptError


class ReceiptTests(unittest.TestCase):
    def test_rejects_wrong_context_duplicate_and_missing_closure(self):
        with tempfile.TemporaryDirectory(dir=".") as tmp:
            lane = LaneReceipt(Path(tmp) / "lane", "c", {"k": "trace"}, False, [0])
            b = b"trace"
            raw = {"kind": "child-output", "role": "browser", "payload": {
                "kind": "media", "contextId": "other", "key": "k", "type": "trace", "bytes": len(b),
                "sha256": hashlib.sha256(b).hexdigest(), "data": base64.b64encode(b).decode()}}
            line = lambda: json.dumps(raw).encode() + b"\n"
            with self.assertRaises(ReceiptError):
                lane.consume(line())
            raw["payload"]["contextId"] = "c"
            lane.consume(line())
            with self.assertRaises(ReceiptError):
                lane.consume(line())
            with self.assertRaises(ReceiptError):
                lane.finish()
