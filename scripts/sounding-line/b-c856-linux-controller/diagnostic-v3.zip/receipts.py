"""Receipt reader for the C856 outer supervisor's bounded pipe."""
import base64
import binascii
import hashlib
import json
import os
import threading
from pathlib import Path

MAX_WIRE = 96 << 20
MAX_ALL = 128 << 20
MAX_RECORD = 46 << 20
MAX_OBJECT = 32 << 20
AGGREGATE_LOCK = threading.Lock()


class ReceiptError(ValueError):
    pass


def need(value, code):
    if not value:
        raise ReceiptError(code)


def unique(items):
    result = {}
    for key, value in items:
        need(key not in result, "DUPLICATE_JSON_FIELD")
        result[key] = value
    return result


def json_line(line):
    need(0 < len(line) <= MAX_RECORD and line.endswith(b"\n"), "WIRE_RECORD_BOUND")
    return json.loads(line, object_pairs_hook=unique)


def content(payload):
    n = payload["bytes"]
    need(type(n) is int and 0 < n <= MAX_OBJECT, "WIRE_OBJECT_BOUND")
    text = payload["data"]
    need(isinstance(text, str) and len(text) == ((n + 2) // 3) * 4, "WIRE_BASE64_BOUND")
    try:
        data = base64.b64decode(text, validate=True)
    except (ValueError, binascii.Error):
        raise ReceiptError("WIRE_BASE64") from None
    need(len(data) == n and hashlib.sha256(data).hexdigest() == payload["sha256"], "WIRE_OBJECT_DIGEST")
    return data


class LaneReceipt:
    def __init__(self, destination, context_id, media, expect_snapshot, aggregate):
        self.destination = Path(destination)
        self.destination.mkdir(mode=0o700, exist_ok=False)
        self.context_id = context_id
        self.media = media
        self.expect_snapshot = expect_snapshot
        self.aggregate = aggregate
        self.bytes = 0
        self.wire = 0
        self.objects = {}
        self.closed = []

    def consume(self, line):
        self.wire += len(line)
        need(self.wire <= MAX_WIRE, "WIRE_BOUND")
        record = json_line(line)
        kind = record.get("kind")
        if kind == "child-closed":
            need(record["role"] in ("app", "browser") and record["role"] not in self.closed, "CHILD_CLOSURE")
            self.closed.append(record["role"])
            return record
        if kind != "child-output":
            need(kind in ("child-ready", "application-local-http", "outer-closed", "outer-failure"), "WIRE_RECORD_KIND")
            return record
        payload = record["payload"]
        role = record["role"]
        item = payload["kind"]
        if role == "browser":
            need(payload["contextId"] == self.context_id and item in ("media", "journal", "anonymous-cache"),
                 "BROWSER_RECORD_IDENTITY")
        else:
            need(role == "app" and item == "sqlite-backup" and self.expect_snapshot, "APP_RECORD_IDENTITY")
        if item == "media":
            key = payload["key"]
            need(self.media.get(key) == payload["type"], "MEDIA_OBLIGATION")
            identity = "media-" + hashlib.sha256(key.encode()).hexdigest()
        else:
            identity = item
        need(identity not in self.objects, "DUPLICATE_OBJECT")
        data = content(payload)
        if item == "anonymous-cache":
            need(json.loads(data) == [], "NON_ANONYMOUS_CACHE")
        if item == "sqlite-backup":
            need(data.startswith(b"SQLite format 3\0"), "SQLITE_EXPORT")
        with AGGREGATE_LOCK:
            need(self.aggregate[0] + len(data) <= MAX_ALL, "TOTAL_ORIGINAL_BOUND")
            self.aggregate[0] += len(data)
        self.bytes += len(data)
        path = self.destination / identity
        with path.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        self.objects[identity] = {"bytes": len(data), "sha256": payload["sha256"], **(
            {"key": key, "type": payload["type"]} if item == "media" else {}
        )}
        return {"kind": "retained", "object": identity}

    def finish(self):
        need(self.closed == ["browser", "app"], "STREAM_TEARDOWN")
        expected = {f"media-{hashlib.sha256(key.encode()).hexdigest()}" for key in self.media}
        expected.update(("journal", "anonymous-cache"))
        if self.expect_snapshot:
            expected.add("sqlite-backup")
        need(set(self.objects) == expected, "RETAINED_OBLIGATIONS")
        return self.objects
