"""Synthetic positive controls owned by the observer or one context outer."""
import hashlib
import re
import selectors
import socket
import threading
from pathlib import Path


class Peer:
    def __init__(self, endpoint, directory, marker):
        if not re.fullmatch(r"[a-f0-9]{48}", marker):
            raise ValueError("PEER_MARKER")
        self.marker = marker.encode("ascii")
        self.marker_digest = hashlib.sha256(self.marker).hexdigest()
        root = Path(directory)
        if endpoint["file"] != str(root / "file") or endpoint["unix"] != str(root / "socket"):
            raise ValueError("PEER_PATH")
        root.mkdir(mode=0o700, exist_ok=False)
        with (root / "file").open("xb") as stream:
            stream.write(self.marker)
        self.addresses = (
            (socket.AF_INET, ("127.0.0.1", endpoint["tcp"])),
            (socket.AF_UNIX, endpoint["unix"]),
            (socket.AF_UNIX, "\0" + endpoint["abstract"]),
        )
        self.sockets = []
        self.stop = threading.Event()
        try:
            for family, address in self.addresses:
                listener = socket.socket(family, socket.SOCK_STREAM)
                self.sockets.append(listener)
                listener.bind(address)
                listener.listen(8)
                listener.setblocking(False)
            self.thread = threading.Thread(target=self.serve, daemon=True)
            self.thread.start()
            if (root / "file").read_bytes() != self.marker:
                raise ValueError("PEER_FILE_POSITIVE")
            for family, address in self.addresses:
                with socket.socket(family, socket.SOCK_STREAM) as client:
                    client.settimeout(1)
                    client.connect(address)
                    with client.makefile("rb") as response:
                        if response.read(49) != self.marker:
                            raise ValueError("PEER_SOCKET_POSITIVE")
        except BaseException:
            self.close()
            raise

    def serve(self):
        with selectors.DefaultSelector() as selector:
            for listener in self.sockets:
                selector.register(listener, selectors.EVENT_READ)
            while not self.stop.is_set():
                for event, _ in selector.select(.1):
                    with event.fileobj.accept()[0] as stream:
                        stream.settimeout(.1)
                        try:
                            stream.sendall(self.marker)
                        except OSError:
                            pass

    def close(self):
        self.stop.set()
        thread = getattr(self, "thread", None)
        if thread is not None:
            thread.join(1)
        for listener in self.sockets:
            listener.close()
        if thread is not None and thread.is_alive():
            raise RuntimeError("PEER_SOCKET_CLOSE")


def ready_peer(config, ordinal):
    if set(config) != {"file", "unix", "tcp", "abstract", "marker"} or ordinal not in (1, 2):
        raise ValueError("PEER_SCOPE")
    return Peer(config, f"/state/peer-{ordinal}", config["marker"])
