"""In-branch negative controls for the fixed C856 diagnostic."""
import ctypes
import errno
import json
import os
import re
import socket
import sys

DENIED_FILE = {errno.ENOENT, errno.EACCES, errno.EPERM, errno.EROFS}
DENIED_SOCKET = {errno.ENOENT, errno.EACCES, errno.EPERM, errno.ECONNREFUSED, errno.EHOSTUNREACH}
HOST_DIR = r"/tmp/c856-host-[a-z0-9]{16,48}"
BRANCHES = {"app": "/diagnostic/app.mjs", "browser": "/diagnostic/capture.mjs"}


def need(value, code):
    if not value:
        raise RuntimeError(code)


def test_file(name):
    for mode in (os.O_RDONLY, os.O_WRONLY):
        try:
            descriptor = os.open(name, mode | os.O_NOFOLLOW | os.O_NONBLOCK)
        except OSError as error:
            need(error.errno in DENIED_FILE, "FILE_PROBE_INDETERMINATE")
        else:
            os.close(descriptor)
            raise RuntimeError("FOREIGN_FILE_REACHABLE")


def test_socket(family, address):
    with socket.socket(family, socket.SOCK_STREAM) as client:
        client.settimeout(.5)
        try:
            client.connect(address)
        except OSError as error:
            need(error.errno in DENIED_SOCKET, "SOCKET_PROBE_INDETERMINATE")
        else:
            raise RuntimeError("FOREIGN_SOCKET_REACHABLE")


def probe(branch, config):
    need(branch in BRANCHES and set(config) == {"host", "other"}, "CANARY_CONFIG")
    files, sockets = [], []
    for name, entry in config.items():
        need(set(entry) == {"file", "tcp", "unix", "abstract"}, "CANARY_TARGET")
        root = HOST_DIR if name == "host" else r"/state/peer-[12]"
        need(re.fullmatch(root + r"/file", entry["file"]) and re.fullmatch(root + r"/socket", entry["unix"]),
             "CANARY_PATH")
        need(type(entry["tcp"]) is int and 1024 <= entry["tcp"] <= 65535 and entry["tcp"] != 32145,
             "CANARY_PORT")
        need(re.fullmatch(r"c856-[a-z0-9-]{10,48}", entry["abstract"]), "CANARY_ABSTRACT")
        test_file(entry["file"])
        files.append(f"{branch}:{name}")
        for typ, family, address in (
            ("tcp", socket.AF_INET, ("127.0.0.1", entry["tcp"])),
            ("unix", socket.AF_UNIX, entry["unix"]),
            ("abstract", socket.AF_UNIX, "\0" + entry["abstract"]),
        ):
            test_socket(family, address)
            sockets.append(f"{branch}:{name}:{typ}")
    with open("/state/write-canary", "xb") as stream:
        stream.write(b"c856-scratch")
    need(open("/state/write-canary", "rb").read() == b"c856-scratch", "PRIVATE_SCRATCH")
    os.unlink("/state/write-canary")
    interfaces = {name for _, name in socket.if_nameindex()}
    need(interfaces == {"lo"}, "EXTERNAL_NETWORK_INTERFACE")
    app_locked = False
    if branch == "app":
        libc = ctypes.CDLL(None, use_errno=True)
        result = libc.unshare(0x10000000)
        need(result == -1 and ctypes.get_errno() in (errno.EPERM, errno.ENOSPC, errno.EUSERS), "APP_USERNS_LOCK")
        app_locked = True
    return {"kind": "branch-controls", "branch": branch, "fileDenials": files,
            "socketDenials": sockets, "appUsernsLocked": app_locked}


def main():
    branch, *ordinal = sys.argv[1:]
    need(branch in BRANCHES and (ordinal in (["1"], ["2"]) if branch == "browser" else not ordinal),
         "CANARY_EXEC")
    with open("/inputs/controls.json", "rb") as source:
        config = source.read(4097)
    need(len(config) <= 4096, "CANARY_BOUND")
    print(json.dumps(probe(branch, json.loads(config))), flush=True)
    os.execve("/usr/bin/node", ["/usr/bin/node", BRANCHES[branch], *ordinal], os.environ)


if __name__ == "__main__":
    main()
