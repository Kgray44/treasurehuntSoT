"""Entrypoint for the reviewed C856 diagnostic after explicit runner admission."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import secrets
import signal
import socket
import stat
import sys
import threading
import time
from pathlib import Path
from package import file_identity

from archive import authenticated_package
from boundary import NAMESPACES, verify_observation
from compare_actual import SOURCE, compare_four, read_original
from lane import run_lane
from package import dependency_receipt, verify_installed
from peers import Peer
from receipts import need

MAX_CAPSULE = 6 << 30
MAX_ENTRIES = 120000
MIN_FREE = 2 << 30
PHASE_SECONDS = {"packageAndPreflight": 300, "pairControls": 60, "staging": 240, "comparison": 720, "receipts": 180}
SHA = re.compile(r"[a-f0-9]{64}")


def clock_limit(seconds):
    def expired(_signal, _frame):
        raise TimeoutError("DIAGNOSTIC_DEADLINE")
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(seconds)


def canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("ascii")


def digest_file(file, expected_bytes, expected_digest):
    with os.fdopen(os.open(file, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as handle:
        first = os.fstat(handle.fileno())
        need(stat.S_ISREG(first.st_mode) and first.st_nlink == 1 and first.st_size == expected_bytes,
             "CAPSULE_FILE_IDENTITY")
        result = hashlib.file_digest(handle, "sha256").hexdigest()
        last = os.fstat(handle.fileno())
    need(file_identity(first) == file_identity(last) == file_identity(file.stat(follow_symlinks=False)) and result == expected_digest, "CAPSULE_FILE_CHANGED")


def capsule(root, manifest_path, manifest_sha):
    with manifest_path.open("rb") as stream:
        manifest = stream.read((24 << 20) + 1)
    need(0 < len(manifest) <= 24 << 20 and hashlib.sha256(manifest).hexdigest() == manifest_sha,
         "CAPSULE_MANIFEST_SHA256")
    config = json.loads(manifest)
    files = config["files"]
    need(config["source"] == SOURCE and len(files) <= MAX_ENTRIES and
         config["tree"] == "1f92226da882098af1fdd6d42a3e43927f6ad676", "CAPSULE_SOURCE")
    need(root.resolve(strict=True) == root and root.stat().st_uid == os.geteuid() and
         re.fullmatch(r"/[A-Za-z0-9_./-]+", str(root)), "CAPSULE_ROOT")
    observed, total = set(), 0
    for parent, directories, names in os.walk(root, followlinks=False):
        base = Path(parent)
        for name in (".", *directories):
            directory = base / name
            inode = directory.lstat()
            need(stat.S_ISDIR(inode.st_mode) and not inode.st_mode & 0o222, "CAPSULE_DIRECTORY")
        for name in names:
            file = base / name
            key = file.relative_to(root).as_posix()
            need(key in files and key not in observed and len(observed) < MAX_ENTRIES, "CAPSULE_INVENTORY")
            observed.add(key)
            spec = files[key]
            need(type(spec["bytes"]) is int and spec["bytes"] >= 0 and SHA.fullmatch(spec["sha256"]),
                 "CAPSULE_ENTRY")
            total += spec["bytes"]
            st = file.lstat()
            need(total <= MAX_CAPSULE and st.st_size == spec["bytes"] and not st.st_mode & 0o7222,
                 "CAPSULE_RESOURCE_OR_MODE")
            digest_file(file, spec["bytes"], spec["sha256"])
    need(observed == set(files), "CAPSULE_INVENTORY")
    return config


def policy():
    paths = (
        "/proc/sys/kernel/apparmor_restrict_unprivileged_userns",
        "/proc/sys/kernel/unprivileged_userns_clone",
        "/proc/sys/user/max_user_namespaces",
        "/proc/self/attr/current",
    )
    return {path: Path(path).read_text(encoding="utf-8").strip() if Path(path).exists() else None for path in paths}


def endpoint(root, port):
    return {"file": root + "/file", "unix": root + "/socket", "tcp": port,
            "abstract": "c856-" + secrets.token_hex(16), "marker": secrets.token_hex(24)}


def review_input(lane, unchanged):
    procs = lane["processes"]
    controls = lane["controls"]
    listener = controls["localHttp"]["owner"]
    need(listener["namespaces"] == procs["app"]["namespaces"] and
         listener["capEff"] == 0 and listener["noNewPrivs"] is True and
         controls["localHttp"]["port"] == 32145, "APP_LISTENER_SCOPE")
    return {
        **procs,
        "browserExecutableVerified": True, "rendererExecutableVerified": True,
        "rendererDescendantVerified": True, "nativeFlagsVerified": True,
        "closedPids": [item["pid"] for item in procs.values()] if lane["allPidfdsExited"] else [],
        "fileDenials": [value for role in ("app", "browser") for value in controls[role]["fileDenials"]],
        "socketDenials": [value for role in ("app", "browser") for value in controls[role]["socketDenials"]],
        "authoredPageAndListenerVerified": True, "hostControlsPositive": True,
        "appNewUsernsDenied": controls["app"]["appUsernsLocked"],
        "browserPrivateProcVerified": True, "browserMapWritesVerified": True,
        "hostPolicyUnchanged": unchanged, "loopbackOnly": True, "closedStreams": lane["allPipesClosed"],
    }


def check_lane(lane):
    procs = lane["processes"]
    return {
        "contextId": lane["contextId"], "observerRuntimeVerified": True, "allPidfdsExited": True,
        "allPipesClosed": True, "networkNamespaceClosed": True, "seedSha256": lane["seedSha256"],
        "launchIdentity": hashlib.sha256(canonical_json(procs)).hexdigest(),
    }



def pair(bundle, output, prepared, seed, second_seed, chromium, host, host_namespaces, first_policy, aggregate, mode):
    endpoints = [endpoint("/state/peer-1", 32451), endpoint("/state/peer-2", 32452)]
    start, end = threading.Barrier(2), threading.Barrier(2)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        calls = []
        for i, context in enumerate(prepared["contexts"]):
            index = {entry["key"]: entry["logical"]["type"] for entry in prepared["obligations"]
                     if entry["contextId"] == context["contextId"] and entry["logical"]["type"] in (
                         "screenshot", "recording", "trace")}
            calls.append(pool.submit(
                run_lane, bundle, output / f"{mode}-{i+1}", context, index,
                seed if i == 0 or mode != "resumed" else second_seed,
                endpoints[i], endpoints[1-i], host, chromium, start, end, aggregate,
                snapshot=mode == "prefix" and i == 0,
                sentinel_only=(mode == "prefix" and i == 1) or (mode == "resumed" and i == 0),
            ))
        results = [task.result() for task in calls]
    unchanged = policy() == first_policy
    active = [item for item in results if item["receipt"] is not None]
    observed = [review_input(item, unchanged) for item in active]
    if len(observed) == 2:
        verify_observation(host_namespaces, observed)
    else:
        need(len(observed) == 1, "ACTIVE_CONTEXT")
        sentinel = next(item for item in results if item["receipt"] is None)
        outer = sentinel["processes"]["outer"]
        need(outer["noNewPrivs"] is True and outer["capEff"] == 0 and
             sentinel["allPidfdsExited"] and sentinel["allPipesClosed"], "SENTINEL_CLOSURE")
        verify_observation(host_namespaces, observed, sentinel=outer["namespaces"])
    for i, result in enumerate(results):
        if result["receipt"] is not None:
            result["external"] = check_lane(result)
            persisted = output / f"{mode}-{i+1}" / "observer.json"
            with persisted.open("xb") as stream:
                stream.write(canonical_json(result) + b"\n")
    return results


def execute(arguments):
    need(sys.platform == "linux" and os.getuid() != 0 and hasattr(os, "pidfd_open"), "LINUX_RUNNER_ADMISSION")
    need(os.getenv("GITHUB_ACTIONS") == "true" and os.getenv("GITHUB_REPOSITORY") == "Kgray44/treasurehuntSoT" and
         os.getenv("GITHUB_RUN_ATTEMPT") == "1" and os.getenv("GITHUB_ACTOR") == "Kgray44", "OWNER_FIRST_ATTEMPT")
    need(os.getenv("GITHUB_EVENT_NAME") == "workflow_dispatch" and os.getenv("GITHUB_TRIGGERING_ACTOR") == "Kgray44"
         and re.fullmatch(r"[a-f0-9]{40}", arguments.controller_sha)
         and os.getenv("GITHUB_SHA") == os.getenv("GITHUB_WORKFLOW_SHA") == arguments.controller_sha,
         "APPROVED_CONTROLLER_SOURCE")
    need(not ({"GH_TOKEN", "GITHUB_TOKEN", "ACTIONS_ID_TOKEN_REQUEST_TOKEN"} & os.environ.keys()), "TOKEN_ENVIRONMENT")
    output = arguments.output
    output.mkdir(mode=0o700, exist_ok=False)
    stages, started = {}, time.monotonic()
    clock_limit(sum(PHASE_SECONDS.values()))
    try:
        t = time.monotonic()
        deb, executable, package = authenticated_package()
        with os.fdopen(os.open("/dev/null", os.O_RDONLY), "rb"):
            directory = os.open("/usr/bin", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                need(verify_installed(directory, executable) == package["binarySha256"], "INSTALLED_PACKAGE")
            finally:
                os.close(directory)
        package["dependencyClosure"] = dependency_receipt(executable)
        stages["packageAndPreflight"] = time.monotonic() - t
        need(stages["packageAndPreflight"] <= PHASE_SECONDS["packageAndPreflight"], "PACKAGE_PHASE_DEADLINE")
        t = time.monotonic()
        info = capsule(arguments.bundle, arguments.manifest, arguments.manifest_sha256)
        prepared = json.loads((arguments.bundle / "children/browser/inputs/plan.json").read_bytes())
        need(prepared["plan"]["candidateSha"] == SOURCE and len(prepared["contexts"]) == 2 and
             len(prepared["obligations"]) == 16 and SHA.fullmatch(info["chromiumSha256"]), "PREPARED_COVERAGE")
        with arguments.seed.open("rb") as stream:
            seed = stream.read((32 << 20) + 1)
        need(512 <= len(seed) <= 32 << 20 and hashlib.sha256(seed).hexdigest() == info["seedSha256"], "SEED_SOURCE")
        stages["staging"] = time.monotonic() - t
        need(stages["staging"] <= PHASE_SECONDS["staging"], "STAGING_PHASE_DEADLINE")
        need(os.statvfs(output).f_bavail * os.statvfs(output).f_frsize > MIN_FREE + (130 << 20), "RUNNER_FREE_SPACE")
        host_namespaces = {name: os.readlink("/proc/self/ns/" + name) for name in NAMESPACES}
        first_policy = policy()
        aggregate = [0]
        t = time.monotonic()
        root = "/tmp/c856-host-" + secrets.token_hex(16)
        positive = None
        try:
            with socket.socket() as allocator:
                allocator.bind(("127.0.0.1", 0))
                port = allocator.getsockname()[1]
            host = endpoint(root, port)
            positive = Peer(host, root, host["marker"])
            args = (arguments.bundle, output, prepared, seed)
            common = (info["chromiumSha256"], host, host_namespaces, first_policy, aggregate)
            fresh = pair(*args, seed, *common, "fresh")
            prefix = pair(*args, seed, *common, "prefix")[0]
            before_resume = json.loads(canonical_json(prefix["receipt"]))
            backup = read_original(Path(prefix["root"]) / "sqlite-backup",
                                   before_resume["sqlite-backup"], [0])
            resume = pair(*args, backup, *common, "resumed")[1]
            result = compare_four(prepared, fresh, [prefix, resume], before_resume)
        finally:
            if positive is not None:
                positive.close()
                owned = Path(root)
                for name in ("file", "socket"):
                    (owned / name).unlink(missing_ok=True)
                owned.rmdir()
        stages["comparison"] = time.monotonic() - t
        need(stages["comparison"] <= PHASE_SECONDS["comparison"], "COMPARISON_PHASE_DEADLINE")
        return {**result, "source": SOURCE, "package": package, "stagesSeconds": stages,
                "runId": os.environ["GITHUB_RUN_ID"], "imageVersion": os.environ["ImageVersion"],
                "elapsedSeconds": time.monotonic() - started}
    except BaseException as error:
        with (output / "failure.json").open("xb") as stream:
            stream.write(canonical_json({"kind": "B_C856_DIAGNOSTIC_FAILURE", "source": SOURCE,
                "failure": str(error)[:256], "elapsedSeconds": time.monotonic() - started,
                "qualification": False, "reuseAuthorized": False}) + b"\n")
        raise
    finally:
        signal.alarm(0)


def main():
    parser = argparse.ArgumentParser()
    for name in ("bundle", "manifest", "seed", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--controller-sha", required=True)
    options = parser.parse_args()
    result = execute(options)
    with (options.output / "result.json").open("xb") as stream:
        stream.write(canonical_json(result) + b"\n")


if __name__ == "__main__":
    main()
