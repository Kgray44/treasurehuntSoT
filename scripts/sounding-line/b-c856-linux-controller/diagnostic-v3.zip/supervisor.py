"""Trusted outer process for one C856 context.

Runs only in the verified outer bundle. The host observer owns the stdin
release protocol and observes the emitted child IDs via outer PID ancestry.
"""
import base64
import hashlib
import json
import os
import selectors
import subprocess
import sys
import time
import urllib.error
import urllib.request

if __name__ == "__main__":
    sys.path.insert(0, "/diagnostic")

from boundary import app_arguments, browser_arguments
from peers import ready_peer

MAX_DB = 32 << 20
MAX_WIRE = 46 << 20
MAX_STATUS = 8192
MAX_CHILD_SECONDS = 140
FIXED_URL = "http://127.0.0.1:32145/"


def need(value, code):
    if not value:
        raise RuntimeError(code)


def control(limit):
    line = sys.stdin.buffer.readline(limit + 1)
    need(0 < len(line) <= limit and line.endswith(b"\n"), "CONTROL_BOUND")
    return json.loads(line)


def record(kind, **fields):
    sys.stdout.write(json.dumps({"kind": kind, **fields}, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def seed_config(message):
    need(set(message) == {"ordinal", "snapshot", "seed", "sha256", "controls", "own", "sentinelOnly"} and
         type(message["ordinal"]) is int and message["ordinal"] in (1, 2) and
         type(message["snapshot"]) is bool and type(message["sentinelOnly"]) is bool, "CONTROL_SCHEMA")
    controls = json.dumps(message["controls"]).encode("ascii")
    need(len(controls) <= 4096, "CONTROLS_BOUND")
    with open("/state/controls.json", "xb") as stream:
        stream.write(controls)
    os.chmod("/state/controls.json", 0o400)
    data = base64.b64decode(message["seed"], validate=True)
    need(512 <= len(data) <= MAX_DB and data.startswith(b"SQLite format 3\0") and
         hashlib.sha256(data).hexdigest() == message["sha256"], "SEED_BINDING")
    with open("/state/seed.sqlite", "xb") as stream:
        stream.write(data)
    os.chmod("/state/seed.sqlite", 0o400)


def child_ready(role, make_arguments, children):
    status_reader, status_writer = os.pipe2(os.O_CLOEXEC)
    release_reader, release_writer = os.pipe2(os.O_CLOEXEC)
    try:
        child = subprocess.Popen(
            make_arguments(status_writer, release_reader), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, pass_fds=(status_writer, release_reader), close_fds=True,
            env={"PATH": "/usr/bin", "LANG": "C"},
        )
        children.append(child)
        os.close(status_writer)
        status_writer = -1
        os.close(release_reader)
        release_reader = -1
        with selectors.DefaultSelector() as selector:
            selector.register(status_reader, selectors.EVENT_READ)
            parts = bytearray()
            deadline = time.monotonic() + 8
            while True:
                need(selector.select(max(0, deadline - time.monotonic())), "CHILD_SETUP_DEADLINE")
                block = os.read(status_reader, MAX_STATUS - len(parts) + 1)
                if not block:
                    break
                parts.extend(block)
                need(len(parts) <= MAX_STATUS, "CHILD_STATUS_BOUND")
                try:
                    status = json.loads(parts)
                    break
                except json.JSONDecodeError:
                    continue
        status = json.loads(parts)
        pid = status["child-pid"]
        need(type(pid) is int and pid > 1 and child.poll() is None, "CHILD_READY_IDENTITY")
        record("child-ready", role=role, localPid=pid, launcherPid=child.pid)
        need(control(128) == {"release": role}, "EXTERNAL_RELEASE")
        os.write(release_writer, b"\1")
        return child
    finally:
        for fd in (status_reader, status_writer, release_reader, release_writer):
            if fd >= 0:
                os.close(fd)


def app_ready(child):
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        need(child.poll() is None, "APPLICATION_EXIT_BEFORE_READY")
        try:
            with opener.open(FIXED_URL, timeout=2) as response:
                need(response.geturl() == FIXED_URL and response.status == 200 and
                     response.headers.get_content_type() == "text/html" and
                     b"Voyagewright | Stories made to be played" in response.read(256 << 10),
                     "APPLICATION_LOCAL_HTTP")
                return
        except (urllib.error.URLError, TimeoutError):
            time.sleep(.2)
    raise RuntimeError("APPLICATION_READY_DEADLINE")


def finish(child, role, command=None):
    if command is not None:
        child.stdin.write((command + "\n").encode("ascii"))
        child.stdin.flush()
    child.stdin.close()
    deadline = time.monotonic() + (MAX_CHILD_SECONDS if role == "browser" else 15)
    outputs = {"stdout": bytearray(), "stderr": bytearray()}
    with selectors.DefaultSelector() as selector:
        for stream in outputs:
            selector.register(getattr(child, stream), selectors.EVENT_READ, stream)
        while selector.get_map():
            ready = selector.select(max(0, deadline - time.monotonic()))
            need(ready, "CHILD_STREAM_DEADLINE")
            for event, _ in ready:
                block = os.read(event.fd, 65536)
                if not block:
                    selector.unregister(event.fileobj)
                    continue
                output = outputs[event.data]
                output.extend(block)
                need(len(output) <= (MAX_WIRE if event.data == "stdout" else 1 << 20), "CHILD_STREAM_BOUND")
    if outputs["stderr"]:
        sys.stderr.buffer.write(outputs["stderr"])
        sys.stderr.buffer.flush()
    need(child.wait(timeout=max(.1, deadline - time.monotonic())) == 0, "CHILD_EXIT")
    control_seen = False
    for line in outputs["stdout"].splitlines():
        result = json.loads(line)
        if result.get("kind") == "branch-controls":
            need(not control_seen and result.get("branch") == role, "BRANCH_CONTROLS")
            control_seen = True
            record("branch-controls", role=role, payload=result)
            continue
        need(result.get("kind") in {
            "app": {"sqlite-backup"}, "browser": {"media", "journal", "anonymous-cache"}
        }[role], "CHILD_WIRE_RECORD")
        record("child-output", role=role, payload=result)
    need(control_seen, "BRANCH_CONTROLS_MISSING")
    record("child-closed", role=role, stderrBytes=len(outputs["stderr"]),
           stderrSha256=hashlib.sha256(outputs["stderr"]).hexdigest())


def main():
    children = []
    peer = None
    try:
        config = control(MAX_WIRE)
        seed_config(config)
        ordinal = config["ordinal"]
        snapshot = config["snapshot"]
        sentinel_only = config["sentinelOnly"]
        peer = ready_peer(config["own"], ordinal)
        record("peer-positive", ordinal=ordinal, sha256=peer.marker_digest)
        need(control(128) == {"start": True}, "PEER_START_GATE")
        del config
        if sentinel_only:
            record("sentinel-ready-close", ordinal=ordinal)
            need(control(128) == {"close": True}, "OUTER_CLOSE_GATE")
            return
        visible_proc = frozenset(os.listdir("/proc"))
        app = child_ready("app", lambda info, gate: app_arguments(info, gate, visible_proc), children)
        app_ready(app)
        record("application-local-http", origin=FIXED_URL)
        browser = child_ready("browser", lambda info, gate: browser_arguments(info, gate, visible_proc, ordinal), children)
        finish(browser, "browser")
        finish(app, "app", "snapshot" if snapshot else "stop")
        record("outer-ready-close", ordinal=ordinal)
        need(control(128) == {"close": True}, "OUTER_CLOSE_GATE")
        record("outer-closed", ordinal=ordinal)
    finally:
        if peer is not None:
            peer.close()
        for child in reversed(children):
            if child.poll() is None:
                child.kill()
            child.wait(timeout=5)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        detail = str(error)
        record("outer-failure", code=detail if detail.isascii() and detail.replace("_", "").isalnum() and
               detail.isupper() and len(detail) < 65 else type(error).__name__)
        sys.exit(1)
