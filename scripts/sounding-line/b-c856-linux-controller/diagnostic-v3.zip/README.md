# B-C856 Linux diagnostic source candidate

Status: source-only, not admitted for dispatch. The protected source and tree are
31181b7b94816b0cf22c79bcebbaecb24e01eec9 and
1f92226da882098af1fdd6d42a3e43927f6ad676. The actual browser adapter derives two
Homeport account-recovery contexts and 16 obligations from protected source.
Only a detached sealed diagnostic copy gets the one-line native sandbox option.

The candidate uses the Canonical Stonking bubblewrap:amd64 0.12.0-1 package
published as 51272 bytes, verified against SHA-512 in the Ubuntu archive index.
The public member is 80424 bytes with SHA-256
5d1f77a455d3a5cc1a45bdbf2e23b89cbd7b33e640dd9ae3b5ce2573d133889e.
This differs from the existing Cloud executable hash
573236e5328ac2ebb08f59ae3a9805b4f8d12bdef14be8af4450d5463294985f.
The Windows readback used publication digests. Authenticating the archive
with the runner's trusted Ubuntu keyring remains a live admission step.

archive.py verifies the base and both moving pockets. package.py pins the
package again before selecting the exact ELF member and publishing it at the
canonical /usr/bin/bwrap path through exclusive staging and a no-replace
hard link. Any future privileged invocation must run separately reviewed
root-owned bytes, through isolated Python, with only the already
authenticated pinned package on stdin. A workspace-writable script must never
be executed as root. The provider setup must verify the Ubuntu loader and
dependency closure against its image and reject ABI or policy denial.

The source files implement separate per-context outer namespaces and sibling
app/browser children on each context's own private loopback. The app branch
keeps its nested user namespace lock. The Chromium worker uses the native
sandbox, and the observer independently checks live executable hashes, PID
identity, renderer user/PID namespace separation, seccomp and private proc.
Paired synthetic host and other-context sentinels cover file and TCP,
filesystem and abstract Unix sockets. The receiver caps, rehashes and retains
originals. Application readiness checks the authored landing title and ties the
loopback listener to a pidfd-tracked application descendant. Synthetic peer
sentinels use a fresh marker. Failure receipts record only tracked pidfds and
do not infer complete descendant closure. The actual comparison seeds two independent fresh contexts, then
captures a separate prefix, restores its synthetic SQLite backup into a new
context and compares the full 16 obligations. Exact screenshot hashes and
unchanged prefix originals are required. The comparator checks ordered trace
actions and actual decoded WebM states to account for capture time variance.
No custody material or live account state is involved.

The frozen source needs an approved controller and a provider-native capsule.
No authenticated native capsule exists in this Windows workspace. A final
launch artifact must bind exact Node, Next build, runtime dependencies, seed,
Playwright Chromium, fonts, decoder, kernel and image. It must demonstrate
the Chromium executable path and both Bubblewrap stages are permitted under
the runner's existing AppArmor policy. Chromium's developer-build rules make
this a real gate. The approved controller may not disable sandbox flags,
adjust profiles or sysctls, or pass provider tokens into lanes. The current
protected workflow set provides no entry point for this capsule. GitHub
controller source must be authenticated separately from the protected app
source, since they have different identities. Use one owner-dispatched job
and one attempt only if the launch is independently reviewed and approved.

Local syntax and failure-test command:
  python -B -m unittest discover -s . -p 'test_*.py' -v
  node --test comparison.test.mjs
On Linux the same Python command exercises no-replace in synthetic scratch.
It imports code only and neither downloads nor stages a package. Place the
Python files together in scratch, use Python 3.11 or later, and verify their
manifest before testing. A package or test transfer must use a separately
authorized route. The packet contains only authored diagnostic code and
public identifiers, with no repo credentials, key, registry or capture data.

Resource planning is one disposable ubuntu-24.04 x64 job, one attempt,
25 runner minutes maximum. Stage ceilings are 5, 1, 4, 12, 3 minutes across
package/preflight, paired controls, staging, comparison and receipt cleanup.
The code has a job deadline, a 6 GiB sealed capsule ceiling, 128 MiB
aggregate original payload ceiling and per-child tmpfs and pipe bounds.
The 12 GiB planned peak including hydration, dependencies and build is
unvalidated and cannot be represented as an admitted provider budget.
Linux staging, scoped proc masks, launch, decoder, full capture and teardown
remain unexecuted. B reuse stays disabled.

References:
https://packages.ubuntu.com/stonking/amd64/bubblewrap
https://documentation.ubuntu.com/security/software-integrity/archive-verification/
https://documentation.ubuntu.com/security/security-features/privilege-restriction/apparmor/
https://chromium.googlesource.com/chromium/src/+/main/docs/security/apparmor-userns-restrictions.md
