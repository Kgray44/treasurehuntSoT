"""Fixed C856 split-boundary arguments and observer-side admission predicates."""
import os
import re
import select
import sys
from pathlib import Path

NAMESPACES = ("user", "mnt", "pid", "net", "ipc", "uts")
BWRAP = "/usr/bin/bwrap"
PORT = 32145
ROLES = ("outer", "app", "browser", "chromium", "renderer")
BRANCHES = ("app", "browser")
TARGETS = ("host", "other")
SOCKETS = ("tcp", "unix", "abstract")
PROC_DIRECTORIES = ("acpi", "bus", "driver", "fs", "irq", "sys", "sysvipc", "tty")
PROC_FILES = (
    "bootconfig", "buddyinfo", "cmdline", "consoles", "devices", "diskstats", "dma",
    "execdomains", "interrupts", "iomem", "ioports", "kallsyms", "kcore", "keys", "kmsg",
    "kpagecgroup", "kpagecount", "kpageflags", "locks", "misc", "modules", "mtrr", "pagetypeinfo",
    "partitions", "sched_debug", "schedstat", "slabinfo", "softirqs", "swaps", "sysrq-trigger",
    "timer_list", "vmallocinfo", "vmstat", "zoneinfo",
)


class BoundaryError(ValueError):
    pass


def need(value, code):
    if not value:
        raise BoundaryError(code)


def common(root, info_fd, gate_fd):
    need(type(info_fd) is int and type(gate_fd) is int and min(info_fd, gate_fd) >= 3 and info_fd != gate_fd, "CONTROL_FDS")
    return [
        BWRAP, "--unshare-user", "--unshare-pid", "--unshare-ipc", "--unshare-uts",
        "--new-session", "--die-with-parent", "--cap-drop", "ALL", "--clearenv",
        "--setenv", "PATH", "/usr/bin", "--setenv", "HOME", "/state",
        "--setenv", "TMPDIR", "/tmp", "--setenv", "LANG", "C.UTF-8",
        "--ro-bind", root, "/", "--proc", "/proc", "--dev", "/dev",
        "--size", str(64<<20), "--tmpfs", "/tmp",
        "--size", str(32<<20), "--tmpfs", "/dev/shm",
        "--size", str(1<<20), "--tmpfs", "/run",
        "--info-fd", str(info_fd), "--block-fd", str(gate_fd),
    ]


def outer_arguments(root, info_fd, gate_fd):
    need(isinstance(root, str) and re.fullmatch(r"/[A-Za-z0-9_./-]+", root) and
         not any(p in (".", "..") for p in root.split("/")) and "//" not in root, "OUTER_ROOT")
    return common(root, info_fd, gate_fd) + [
        "--unshare-net", "--size", str(72<<20), "--tmpfs", "/state", "--chdir", "/state",
        "--", "/usr/bin/python3", "-IB", "/diagnostic/supervisor.py",
    ]


def mask_proc(visible):
    # Source paths are empty sealed regular entries from the outer bundle.
    return [arg for name in PROC_DIRECTORIES + PROC_FILES if name in visible for arg in (
        "--ro-bind", "/masks/dir" if name in PROC_DIRECTORIES else "/masks/file", f"/proc/{name}"
    )]


def app_arguments(info_fd, gate_fd, visible=()):
    return common("/children/app", info_fd, gate_fd) + [
        "--disable-userns", *mask_proc(visible), "--remount-ro", "/proc",
        "--size", str(96<<20), "--tmpfs", "/state", "--chdir", "/source",
        "--ro-bind", "/state/seed.sqlite", "/inputs/seed.sqlite",
        "--ro-bind", "/state/controls.json", "/inputs/controls.json",
        "--", "/usr/bin/python3", "-IB", "/diagnostic/probe.py", "app",
    ]


def browser_arguments(info_fd, gate_fd, visible=(), ordinal=1):
    # No --unshare-net here. The only parent of this child is the isolated
    # outer supervisor, and the observer requires exact outer net identity.
    return common("/children/browser", info_fd, gate_fd) + [
        *mask_proc(visible), "--setenv", "PLAYWRIGHT_BROWSERS_PATH", "/browsers", "--size", str(64<<20), "--tmpfs", "/state",
        "--size", str(112<<20), "--tmpfs", "/source/artifacts", "--chdir", "/source",
        "--ro-bind", "/state/controls.json", "/inputs/controls.json",
        "--", "/usr/bin/python3", "-IB", "/diagnostic/probe.py", "browser", str(ordinal),
    ]


def process_identity(pid, pidfd):
    """Host-observed proc identity. Caller owns and retains the pidfd."""
    need(sys.platform == "linux" and type(pid) is int and pid > 1, "LINUX_PROCESS")
    poller = select.poll()
    poller.register(pidfd, select.POLLIN | select.POLLHUP | select.POLLERR)
    fdinfo = Path(f"/proc/self/fdinfo/{pidfd}").read_text(encoding="ascii")
    need(f"Pid:\t{pid}\n" in fdinfo and not poller.poll(0), "STALE_PIDFD")
    proc = Path(f"/proc/{pid}")
    def start():
        stat = (proc / "stat").read_text(encoding="ascii")
        return int(stat.rsplit(") ", 1)[1].split()[19])
    before = start()
    status = dict(line.split(":\t", 1) for line in (proc / "status").read_text(encoding="ascii").splitlines()
                  if ":\t" in line)
    result = {
        "pid": pid, "startTicks": before,
        "namespaces": {name: os.readlink(proc / "ns" / name) for name in NAMESPACES},
        "noNewPrivs": status["NoNewPrivs"] == "1",
        "capEff": int(status["CapEff"], 16), "seccomp": int(status["Seccomp"]),
    }
    need(start() == before and not poller.poll(0), "STALE_PIDFD")
    return result


def check_namespaces(observed):
    need(set(observed) == set(NAMESPACES) and all(
        re.fullmatch(rf"{name}:\[[1-9][0-9]*\]", observed[name]) for name in NAMESPACES
    ), "NAMESPACE_ID")


def verify_observation(host, lanes, sentinel=None):
    """Reject incomplete independently captured evidence. Never trust a worker JSON as an observer."""
    check_namespaces(host)
    need((len(lanes) == 2 and sentinel is None) or (len(lanes) == 1 and sentinel is not None), "TWO_CONTEXTS")
    pids = set()
    seen = {name: {host[name]} for name in NAMESPACES}
    if sentinel is not None:
        check_namespaces(sentinel)
        for name in NAMESPACES:
            need(sentinel[name] != host[name], "SENTINEL_NAMESPACE")
            seen[name].add(sentinel[name])
    file_denials = {f"{branch}:{target}" for branch in BRANCHES for target in TARGETS}
    socket_denials = {f"{branch}:{target}:{kind}" for branch in BRANCHES for target in TARGETS for kind in SOCKETS}
    assertions = (
        "browserExecutableVerified", "rendererExecutableVerified", "rendererDescendantVerified",
        "nativeFlagsVerified", "authoredPageAndListenerVerified", "hostControlsPositive", "appNewUsernsDenied",
        "browserPrivateProcVerified", "browserMapWritesVerified", "hostPolicyUnchanged",
        "loopbackOnly", "closedStreams",
    )
    for lane in lanes:
        members = [lane[role] for role in ROLES]
        for item in members:
            check_namespaces(item["namespaces"])
            pid = item["pid"]
            need(type(pid) is int and pid > 1 and pid not in pids and
                 type(item["startTicks"]) is int and item["startTicks"] > 0 and
                 item["noNewPrivs"] is True and item["capEff"] == 0, "PROCESS_IDENTITY")
            pids.add(pid)
        outer, app, browser, chromium, renderer = (item["namespaces"] for item in members)
        need(chromium == browser, "CHROMIUM_WORKER_NAMESPACE")
        need(outer["net"] == app["net"] == browser["net"] and outer["net"] not in seen["net"], "LANE_NETWORK")
        need(renderer["user"] != browser["user"] and renderer["pid"] != browser["pid"] and
             lane["renderer"]["seccomp"] == 2, "CHROMIUM_NATIVE_SANDBOX")
        for name in NAMESPACES:
            distinct = {outer[name], app[name], browser[name], renderer[name]}
            if name != "net":
                expected = {outer[name], app[name], browser[name]}
                need(len(expected) == 3, "SIBLING_NAMESPACE")
            need(distinct.isdisjoint(seen[name]), "HOST_OR_CROSS_CONTEXT_NAMESPACE")
            seen[name].update(distinct)
        need(all(lane.get(key) is True for key in assertions), "MISSING_OBSERVER_PROOF")
        need(len(lane["fileDenials"]) == len(file_denials) and set(lane["fileDenials"]) == file_denials and
             len(lane["socketDenials"]) == len(socket_denials) and set(lane["socketDenials"]) == socket_denials,
             "ISOLATION_NEGATIVE_CONTROLS")
        need(sorted(lane["closedPids"]) == sorted(item["pid"] for item in members), "INCOMPLETE_TEARDOWN")
