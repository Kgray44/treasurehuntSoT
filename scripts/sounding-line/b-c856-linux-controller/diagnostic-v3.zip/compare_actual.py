"""Compare C856's four retained context runs, with no worker-supplied semantics."""
import hashlib
import json
import os
from pathlib import Path
from package import file_identity

from media import ordered_witness, pixels, probe_recording, trace_semantics
from receipts import MAX_ALL, MAX_OBJECT, need

SOURCE = "31181b7b94816b0cf22c79bcebbaecb24e01eec9"
SOURCE_BINDINGS = "351babed4eea7b07decfa6fcaba6dcb2e49e033e13115788f3c845461984f317"
CONTRACT_DIGEST = "98fbeda9cd33e7a771a42a171e33ae23dff549f00ba5943df130d905769b982e"


def read_original(path, expected, consumed):
    # The receiver creates these directories exclusively and exports no paths.
    need(path.resolve(strict=True) == path, "RETAINED_PATH_ALIAS")
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), "rb") as stream:
        before = os.fstat(stream.fileno())
        data = stream.read(min(expected["bytes"], MAX_OBJECT) + 1)
        after = os.fstat(stream.fileno())
        named = path.stat(follow_symlinks=False)
    need(file_identity(before) == file_identity(after) == file_identity(named) and before.st_nlink == 1 and len(data) == expected["bytes"] == before.st_size,
         "RETAINED_FILE_CHANGED")
    need(hashlib.sha256(data).hexdigest() == expected["sha256"], "RETAINED_HASH_CHANGED")
    consumed[0] += len(data)
    need(consumed[0] <= MAX_ALL, "COMPARISON_BYTE_BOUND")
    return data


def inspect_context(root, context, obligations, receipt, external, consumed):
    need(external["contextId"] == context["contextId"] and external["observerRuntimeVerified"] is True and
         external["allPidfdsExited"] is True and external["allPipesClosed"] is True and
         external["networkNamespaceClosed"] is True, "EXTERNAL_CLEANUP")
    need(len(obligations) == 8, "CONTEXT_COVERAGE")
    expected = {f"media-{hashlib.sha256(item['key'].encode()).hexdigest()}": item
                for item in obligations if item["logical"]["type"] in ("screenshot", "trace", "recording")}
    need(len(expected) == 5 and set(receipt) - {"journal", "anonymous-cache", "sqlite-backup"} == set(expected),
         "MEDIA_COVERAGE")
    document = read_original(root / "journal", receipt["journal"], consumed)
    journal = json.loads(document)
    need(journal["context"] == context["context"] and
         journal["binding"] == {"baseSha": SOURCE, "candidateSha": SOURCE, "sourceDigest": SOURCE_BINDINGS,
                                "contractDigest": CONTRACT_DIGEST, "recordDigest": None} and
         journal["qualification"] is False and journal["reuseAuthorized"] is False and
         journal["classification"] == "CLOSED_BROWSER_CONTEXT_OBSERVATION_NOT_RUNTIME_CLEANUP",
         "JOURNAL_CONTEXT")
    auth = read_original(root / "anonymous-cache", receipt["anonymous-cache"], consumed)
    need(json.loads(auth) == [], "ANONYMOUS_CACHE")
    journey = dict(journal["journey"])
    need(journey["status"] == "PASS" and journey["roleVerified"] is True, "JOURNEY_STATUS")
    timing = journey.pop("feedbackMs")
    need(type(timing) in (int, float) and 0 <= timing <= 120000, "JOURNEY_FEEDBACK_TIMING")
    accessibility = journey.get("accessibility")
    need(isinstance(accessibility, dict) and bool(accessibility.get("states")), "ACCESSIBILITY_STATE")
    values = {}
    screenshots = []
    recording = None
    for identity, item in expected.items():
        descriptor = receipt[identity]
        need(descriptor["key"] == item["key"] and descriptor["type"] == item["logical"]["type"], "ORIGINAL_MEDIA_KEY")
        media = read_original(root / identity, descriptor, consumed)
        kind = descriptor["type"]
        if kind == "screenshot":
            need(media[:8] == b"\x89PNG\r\n\x1a\n", "SCREENSHOT_PNG")
            screenshots.append((item["logical"]["captureIndex"], media))
            values[item["key"]] = descriptor["sha256"]
        elif kind == "trace":
            values[item["key"]] = trace_semantics(media)
        else:
            recording = (item["key"], media)
    need(len(screenshots) == 3 and recording is not None, "RECORDING_WITNESSES")
    viewport = context["context"]["viewport"]
    metadata = probe_recording(recording[1], (viewport["width"], viewport["height"]))
    ordered_witness(pixels(recording[1], True), [pixels(media, False)[0] for _, media in sorted(screenshots)])
    values[recording[0]] = {**metadata, "orderedWitnessCount": 3}
    for item in obligations:
        typ = item["logical"]["type"]
        if typ == "accessibility":
            values[item["key"]] = accessibility
        if typ == "journey":
            values[item["key"]] = journey
        if typ == "cleanup":
            values[item["key"]] = {"allPidfdsExited": True, "allPipesClosed": True, "networkNamespaceClosed": True}
    need(len(values) == 8, "CONTEXT_OBLIGATION_CLOSURE")
    return values


def compare_four(prepared, fresh, resumed, prefix_receipt_before_resume):
    # Each lane item comprises independently observed external runtime state,
    # receiver-owned original directory, and exclusively written hash receipts.
    need(len(prepared["contexts"]) == len(fresh) == len(resumed) == 2 and len(prepared["obligations"]) == 16,
         "TWO_CONTEXTS_16_OBLIGATIONS")
    need(prefix_receipt_before_resume == resumed[0]["receipt"], "PREFIX_RECEIPT_DRIFT")
    need("sqlite-backup" in prefix_receipt_before_resume and
         resumed[1]["external"]["seedSha256"] == prefix_receipt_before_resume["sqlite-backup"]["sha256"] and
         fresh[0]["external"]["seedSha256"] == fresh[1]["external"]["seedSha256"] ==
         resumed[0]["external"]["seedSha256"], "RESUME_SEED_BINDING")
    need(len({item["external"]["launchIdentity"] for item in (*fresh, *resumed)}) == 4, "DISTINCT_EXECUTIONS")
    consumed = [0]
    snapshot = read_original(Path(resumed[0]["root"]) / "sqlite-backup",
                             prefix_receipt_before_resume["sqlite-backup"], consumed)
    need(snapshot.startswith(b"SQLite format 3\0"), "SQLITE_PREFIX")
    count = 0
    for ordinal, context in enumerate(prepared["contexts"]):
        obligations = [item for item in prepared["obligations"] if item["contextId"] == context["contextId"]]
        before, after = [
            inspect_context(Path(run["root"]), context, obligations, run["receipt"], run["external"], consumed)
            for run in (fresh[ordinal], resumed[ordinal])
        ]
        need(before == after, "FRESH_RESUMED_SEMANTICS")
        count += len(before)
    need(count == 16, "COMPLETE_COMPARISON")
    return {"kind": "B_C856_CAPTURE_COMPARISON_DIAGNOSTIC", "contexts": 2, "obligations": count,
            "originalBytesCompared": consumed[0], "qualification": False, "reuseAuthorized": False}
