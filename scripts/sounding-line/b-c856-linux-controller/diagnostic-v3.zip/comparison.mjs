import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { constants } from "node:fs";
import { lstat, open, realpath } from "node:fs/promises";
import path from "node:path";

export const MAX_OBJECT = 32 << 20;
export const MAX_LANE = 32 << 20;
export const MAX_ALL = 128 << 20;
export const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");

export async function readOriginal(root, relative, expected, maximum = MAX_OBJECT) {
  assert(typeof relative === "string" && !relative.includes("\\") &&
    relative.split("/").every((piece) => piece && piece !== "." && piece !== ".."));
  const file = path.resolve(root, relative);
  assert(file.startsWith(path.resolve(root) + path.sep) && await realpath(file) === file);
  const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
  try {
    const before = await handle.stat({ bigint: true });
    assert(before.isFile() && before.nlink === 1n && before.size > 0n && before.size <= BigInt(maximum));
    const bytes = Buffer.alloc(Number(before.size) + 1);
    let length = 0;
    while (length < bytes.length) {
      const part = await handle.read(bytes, length, bytes.length - length, null);
      if (!part.bytesRead) break;
      length += part.bytesRead;
    }
    const after = await handle.stat({ bigint: true });
    const named = await lstat(file, { bigint: true });
    assert.equal(length, Number(before.size));
    for (const observed of [after, named])
      for (const key of ["dev", "ino", "size", "ctimeNs", "mtimeNs"])
        assert.equal(observed[key], before[key], "ORIGINAL_CHANGED");
    const original = bytes.subarray(0, length);
    if (expected) assert.equal(hash(original), expected, "ORIGINAL_SHA256");
    return original;
  } finally {
    await handle.close();
  }
}

export function selectJournal(obligations, journal) {
  assert.equal(obligations.length, 8);
  assert.equal(journal.classification, "CLOSED_BROWSER_CONTEXT_OBSERVATION_NOT_RUNTIME_CLEANUP");
  assert.equal(journal.qualification, false);
  assert.equal(journal.reuseAuthorized, false);
  assert.equal(journal.journey.status, "PASS");
  assert.equal(journal.journey.id, journal.context.journeyId);
  assert(journal.journey.accessibility.states.length > 0);
  assert.equal(journal.artifacts.length, 5);
  assert.equal(journal.rawFiles.length, 5);
  const bound = obligations.filter(({ logical }) => ["screenshot", "trace", "recording"].includes(logical.type));
  const selected = new Set();
  return bound.map(({ key, logical }) => {
    for (const name of ["contractId", "journeyId", "role", "device", "motionMode"])
      assert.equal(journal.context[name], logical[name]);
    assert.deepEqual(journal.context.viewport, logical.viewport);
    const matches = journal.artifacts.filter((item) => item.type === logical.type && (
      item.type !== "screenshot" || (
        item.state === logical.state &&
        item.id === [logical.contractId, logical.journeyId, logical.device, logical.role, logical.motionMode,
          logical.state, logical.captureIndex].join("-")
      )
    ));
    assert.equal(matches.length, 1, "JOURNAL_MEDIA_SCOPE");
    const [artifact] = matches;
    for (const name of ["contractId", "device", "role", "motionMode"])
      assert.equal(artifact[name], logical[name]);
    assert.equal(artifact.origin, "ACTUAL_APPLICATION");
    const raw = journal.rawFiles.filter((file) => file.originalPath === artifact.path);
    assert.equal(raw.length, 1);
    assert.equal(raw[0].sha256, artifact.sha256);
    assert(Number.isSafeInteger(raw[0].bytes) && raw[0].bytes > 0 && raw[0].bytes <= MAX_OBJECT);
    assert(!selected.has(raw[0].path), "ALIASED_ARTIFACT");
    selected.add(raw[0].path);
    return { key, type: logical.type, original: artifact.path, path: raw[0].path, bytes: raw[0].bytes, sha256: raw[0].sha256 };
  });
}

export function verifyLanes(obligations, fresh, resumed, retainedPrefix) {
  assert.equal(obligations.length, 16);
  const expected = new Map(obligations.map((item) => [item.key, item]));
  assert.equal(expected.size, 16);
  const contexts = [...new Set(obligations.map((item) => item.contextId))];
  assert.equal(contexts.length, 2);
  let total = 0;
  function lane(records) {
    assert.equal(records.length, 16);
    const selected = new Map();
    for (const entry of records) {
      const item = expected.get(entry.key);
      assert(item && !selected.has(entry.key) && item.contextId === entry.contextId);
      assert.equal(entry.type, item.logical.type);
      assert(Buffer.isBuffer(entry.original) && entry.original.length > 0 && entry.original.length <= MAX_OBJECT);
      total += entry.original.length;
      assert(total <= MAX_ALL);
      assert.equal(hash(entry.original), entry.sha256);
      selected.set(entry.key, entry);
    }
    return selected;
  }
  const baseline = lane(fresh), resumedIndex = lane(resumed);
  const prefix = new Map(retainedPrefix.map((entry) => [entry.key, entry.sha256]));
  assert.equal(retainedPrefix.length, 8);
  assert.equal(prefix.size, 8);
  for (const [key, item] of expected) {
    const first = baseline.get(key), second = resumedIndex.get(key);
    if (item.contextId === contexts[0]) assert.equal(prefix.get(key), second.sha256, "PREFIX_ORIGINAL_DRIFT");
    assert(first.semantic !== undefined && second.semantic !== undefined, "INDEPENDENT_SEMANTICS_REQUIRED");
    assert.deepEqual(first.semantic, second.semantic, "FRESH_RESUMED_SEMANTIC_DRIFT");
    if (item.logical.type === "screenshot") assert.equal(first.sha256, second.sha256, "SCREENSHOT_ORIGINAL_DRIFT");
  }
  return { contexts: 2, obligations: 16, originalBytesRead: total, qualification: false, reuseAuthorized: false };
}
