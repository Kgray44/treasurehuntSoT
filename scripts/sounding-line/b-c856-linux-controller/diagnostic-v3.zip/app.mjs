import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { copyFile, readFile, stat } from "node:fs/promises";
import { backup, DatabaseSync } from "node:sqlite";
import { createInterface } from "node:readline";
import { createHash } from "node:crypto";

const ROOT = "/source";
const DB = "/state/runtime.db";
const snapshot = "/state/backup.db";
const MAX_DATABASE = 32 << 20;
const seed = await stat("/inputs/seed.sqlite");
assert(seed.isFile() && seed.size >= 512 && seed.size <= MAX_DATABASE);
await copyFile("/inputs/seed.sqlite", DB);
const child = spawn("/usr/bin/node", [ROOT + "/node_modules/next/dist/bin/next", "start", "-H", "127.0.0.1", "-p", "32145"], {
  cwd: ROOT,
  env: {
    PATH: "/usr/bin", HOME: "/state", TMPDIR: "/tmp", LANG: "C.UTF-8",
    NODE_ENV: "production", NEXT_TELEMETRY_DISABLED: "1", DATABASE_URL: "file:" + DB,
    HOSTNAME: "127.0.0.1", PORT: "32145",
  },
  stdio: ["ignore", 2, 2],
});
const exit = once(child, "exit");
const input = createInterface({ input: process.stdin, crlfDelay: Infinity });
let stopped = false;
try {
  const command = await Promise.race([
    (async () => {
      for await (const value of input) return value;
      return null;
    })(),
    exit.then(() => null),
  ]);
  assert(command === "stop" || command === "snapshot", "APP_CONTROL");
  child.kill("SIGTERM");
  const [code, signal] = await Promise.race([
    exit,
    new Promise((_, reject) => {
      const timer = setTimeout(() => reject(Error("NEXT_TEARDOWN_DEADLINE")), 5000);
      timer.unref();
    }),
  ]);
  stopped = true;
  assert(code === 0 || signal === "SIGTERM", "APP_EXIT");
  if (command === "snapshot") {
    const db = new DatabaseSync(DB, { readOnly: true });
    try {
      await backup(db, snapshot);
    } finally {
      db.close();
    }
    const size = (await stat(snapshot)).size;
    assert(size >= 512 && size <= MAX_DATABASE);
    const bytes = await readFile(snapshot);
    assert.equal(bytes.length, size);
    assert(bytes.subarray(0, 16).equals(Buffer.from("SQLite format 3\0")));
    process.stdout.write(JSON.stringify({ kind: "sqlite-backup", bytes: size,
      sha256: createHash("sha256").update(bytes).digest("hex"), data: bytes.toString("base64") }) + "\n");
  }
} finally {
  input.close();
  if (!stopped) child.kill("SIGKILL");
}
