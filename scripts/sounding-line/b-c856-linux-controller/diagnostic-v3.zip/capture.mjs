import assert from "node:assert/strict";
import { readFile, mkdir } from "node:fs/promises";
import { once } from "node:events";
import { hash, MAX_LANE, readOriginal, selectJournal } from "./comparison.mjs";

const ROOT = "/source";
const INVOCATION = "artifacts/sounding-line/product-experience-capture-staging/capture-b-c856";
const RAW = INVOCATION + "/raw";
const SOURCE = "31181b7b94816b0cf22c79bcebbaecb24e01eec9";
const SOURCE_DIGEST = "351babed4eea7b07decfa6fcaba6dcb2e49e033e13115788f3c845461984f317";
const BROWSER_MODULE = "/source/scripts/sounding-line/experience-browser.mjs";
const frozen = JSON.parse((await readOriginal("/inputs", "plan.json", undefined, 2 << 20)).toString("utf8"));
const browserBytes = await readOriginal("/source", "scripts/sounding-line/experience-browser.mjs",
  frozen.sandboxedCaptureSha256, 2 << 20);
assert(browserBytes.includes(Buffer.from("chromium.launch({ headless: true, chromiumSandbox: true })")));
assert.equal(frozen.plan.baseSha, SOURCE);
assert.equal(frozen.plan.candidateSha, SOURCE);
assert.equal(frozen.plan.sourceDigest, SOURCE_DIGEST);
assert.equal(frozen.contexts.length, 2);
assert.equal(frozen.obligations.length, 16);
const ordinal = Number(process.argv[2]);
assert(process.argv.length === 3 && [1, 2].includes(ordinal));
const selected = frozen.contexts[ordinal - 1];
const contextId = selected.contextId;
assert.match(contextId, /^[0-9a-f]{64}$/);
const obligations = frozen.obligations.filter((item) => item.contextId === contextId);
assert.equal(obligations.length, 8);
const outputDirectory = INVOCATION + "/capture/" + contextId;
await mkdir(RAW, { mode: 0o700, recursive: true });
const { captureProductExperience, shadowCaptureContextSchedule } = await import(BROWSER_MODULE);
assert.deepEqual(shadowCaptureContextSchedule(frozen.plan), frozen.contexts);
const authentication = await readOriginal("/inputs", "authentication.json", undefined, 32768);
assert.deepEqual(JSON.parse(authentication.toString("utf8")), [], "ANONYMOUS_AUTHENTICATION_STATE");
const evidence = await captureProductExperience({
  root: ROOT, plan: frozen.plan, baseURL: "http://127.0.0.1:32145/", outputDirectory,
  rawOutputDirectory: RAW, shadowContext: { mode: "SHADOW_SINGLE_CONTEXT", contextId },
  shadowAuthenticationCache: authentication,
});
assert.equal(evidence.partialContext.contextId, contextId);
assert.equal(evidence.partialContext.ordinal, ordinal);
assert.equal(evidence.journeys.length, 1);
assert.equal(evidence.journeys[0].status, "PASS");

const journal = await readOriginal(ROOT, RAW + "/closed-contexts/" + contextId + "/" + contextId + ".json",
  undefined, 2 << 20);
const parsed = JSON.parse(journal.toString("utf8"));
assert.deepEqual(parsed.context, selected.context);
assert.equal(parsed.binding.baseSha, SOURCE);
assert.equal(parsed.binding.candidateSha, SOURCE);
assert.equal(parsed.binding.sourceDigest, SOURCE_DIGEST);
assert.equal(parsed.binding.contractDigest, frozen.plan.contractDigest);
const cached = await readOriginal(ROOT,
  RAW + "/private-context-state-" + contextId + "/authentication-cache.json",
  evidence.shadowPrivateState.sha256, 32768);
assert.deepEqual(JSON.parse(cached.toString("utf8")), []);
assert.deepEqual(parsed.journey, evidence.journeys[0]);

let exported = 0;
async function exportRecord(kind, bytes, labels = {}) {
  exported += bytes.length;
  assert(exported <= MAX_LANE);
  const record = JSON.stringify({ kind, contextId, ...labels, bytes: bytes.length, sha256: hash(bytes),
    data: bytes.toString("base64") }) + "\n";
  if (!process.stdout.write(record)) await once(process.stdout, "drain");
}

for (const item of selectJournal(obligations, parsed)) {
  const raw = await readOriginal(ROOT, item.path, item.sha256);
  assert.equal(raw.length, item.bytes);
  const original = await readOriginal(ROOT, item.original, item.sha256);
  assert(raw.equals(original), "RAW_ORIGINAL_DRIFT");
  await exportRecord("media", original, { key: item.key, type: item.type });
}
await exportRecord("journal", journal);
await exportRecord("anonymous-cache", cached);
