"""Pinned public download and unprivileged archive authentication.

This module is an input stage for an approved runner. It is not a workflow
entry point and does not install, stage or execute the binary.
"""
import hashlib
import urllib.request
from datetime import datetime, timezone

from package import (
    ARCHIVE, SECURITY_ARCHIVE, POCKETS, INDEX, INDEX_HASH, MIB, PACKAGE, PACKAGE_SIZE,
    exact_record, need, package_records, signed_release, sha512, verified_package_member,
)


def fetch(opener, url, maximum):
    with opener.open(url, timeout=12) as response:
        need(response.geturl() == url and response.status == 200, "ARCHIVE_REDIRECT_OR_STATUS")
        result = response.read(maximum + 1)
    need(0 < len(result) <= maximum, "ARCHIVE_DOWNLOAD_BOUND")
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def authenticated_package(now=None):
    now = datetime.now(timezone.utc) if now is None else now
    opener = urllib.request.build_opener(NoRedirect(), urllib.request.ProxyHandler({}))
    receipts = {}
    for pocket in POCKETS:
        host = SECURITY_ARCHIVE if pocket.endswith("-security") else ARCHIVE
        prefix = host + "dists/" + pocket + "/"
        inrelease = fetch(opener, prefix + "InRelease", 2*MIB)
        release = signed_release(inrelease)
        records = [line.split() for line in release.get("SHA512", "").splitlines()
                   if line.split()[-1:] == [INDEX]]
        need(len(records) == 1 and len(records[0]) == 3, "SIGNED_INDEX_POINTER")
        digest, size, _ = records[0]
        need(len(digest) == 128 and all(char in "0123456789abcdef" for char in digest), "SIGNED_INDEX_SHA512")
        need(size.isascii() and size.isdecimal() and 0 < int(size) <= 8*MIB, "SIGNED_INDEX_SIZE")
        if pocket == POCKETS[0]:
            need(digest == INDEX_HASH, "BASE_INDEX_POINTER")
        compressed = fetch(opener, prefix + INDEX.rsplit("/", 1)[0] + "/by-hash/SHA512/" + digest, int(size))
        selected = package_records(release, compressed, pocket, now)
        if pocket == POCKETS[0]:
            exact_record(selected)
        else:
            need(not selected, "MOVING_PACKAGE_CHANGED")
        receipts[pocket] = {"inReleaseSha256": hashlib.sha256(inrelease).hexdigest(),
                            "indexSha512": digest, "indexBytes": len(compressed)}
    deb = fetch(opener, ARCHIVE + PACKAGE, PACKAGE_SIZE)
    executable = verified_package_member(deb)
    return deb, executable, {"archive": receipts, "packageSha512": sha512(deb),
                              "binarySha256": hashlib.sha256(executable).hexdigest()}
