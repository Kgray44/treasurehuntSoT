"""Pinned public download and unprivileged archive authentication.

This module is an input stage for an approved runner. It is not a workflow
entry point and does not install, stage or execute the binary.
"""
import hashlib
import os
import stat
import subprocess
import sys
import tempfile
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from package import (
    ARCHIVE, SECURITY_ARCHIVE, POCKETS, INDEX, INDEX_HASH, MIB, PACKAGE, PACKAGE_SIZE,
    CLEAN_ENV, exact_record, fields, need, package_records, sha512, verified_package_member,
)


KEYRING = Path("/etc/apt/trusted.gpg.d/ubuntu-keyring-2018-archive.gpg")
KEYRING_BYTES = 1167
KEYRING_SHA256 = "5ebbeeb474034b1fa7e50abbe6f136e177fc826219e01f314b3623f7b3097e96"


def archive_key(path):
    need(path.resolve(strict=True) == path, "ARCHIVE_KEYRING_PATH")
    for component in path.parents:
        record = component.lstat()
        need(stat.S_ISDIR(record.st_mode) and record.st_uid == 0 and
             not record.st_mode & 0o022, "ARCHIVE_KEYRING_OWNER")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        record = os.fstat(stream.fileno())
        need(stat.S_ISREG(record.st_mode) and record.st_uid == 0 and
             not record.st_mode & 0o022, "ARCHIVE_KEYRING_OWNER")
        data = stream.read(KEYRING_BYTES + 1)
    need(len(data) == KEYRING_BYTES and hashlib.sha256(data).hexdigest() == KEYRING_SHA256,
         "ARCHIVE_KEYRING_DIGEST")
    return data


def signed_release(inrelease):
    need(sys.platform == "linux" and 0 < len(inrelease) <= 2*MIB, "RELEASE_SCOPE")
    key = archive_key(KEYRING)
    with tempfile.TemporaryDirectory(prefix="c856-gpgv-") as home:
        keyring = Path(home)/"ubuntu-archive-2018.gpg"
        with keyring.open("xb") as stream:
            stream.write(key)
        keyring.chmod(0o400)
        process = subprocess.run(
            ["/usr/bin/gpgv", "--homedir", home, "--keyring", str(keyring), "--output", "-", "-"],
            input=inrelease, capture_output=True, timeout=15, env=CLEAN_ENV, check=False,
        )
    need(process.returncode == 0 and 0 < len(process.stdout) <= 2*MIB, "RELEASE_SIGNATURE")
    return fields(process.stdout.decode("utf-8", errors="strict"))


def fetch(opener, url, maximum):
    with opener.open(url, timeout=12) as response:
        need(response.geturl() == url and response.status == 200, "ARCHIVE_REDIRECT_OR_STATUS")
        result = response.read(maximum + 1)
    need(0 < len(result) <= maximum, "ARCHIVE_DOWNLOAD_BOUND")
    return result


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def authenticated_package(now=None):
    now = datetime.now(timezone.utc) if now is None else now
    opener = urllib.request.build_opener(NoRedirect(), urllib.request.ProxyHandler({}))
    receipts = {}
    for pocket in POCKETS:
        host = SECURITY_ARCHIVE if pocket.endswith("-security") else ARCHIVE
        prefix = host + "dists/" + pocket + "/"
        inrelease = fetch(opener, prefix + "InRelease", 2*MIB)
        release = signed_release(inrelease)
        records = [line.split() for line in release.get("SHA512", "").splitlines()
                   if line.split()[-1:] == [INDEX]]
        need(len(records) == 1 and len(records[0]) == 3, "SIGNED_INDEX_POINTER")
        digest, size, _ = records[0]
        need(len(digest) == 128 and all(char in "0123456789abcdef" for char in digest), "SIGNED_INDEX_SHA512")
        need(size.isascii() and size.isdecimal() and 0 < int(size) <= 8*MIB, "SIGNED_INDEX_SIZE")
        if pocket == POCKETS[0]:
            need(digest == INDEX_HASH, "BASE_INDEX_POINTER")
        compressed = fetch(opener, prefix + INDEX.rsplit("/", 1)[0] + "/by-hash/SHA512/" + digest, int(size))
        selected = package_records(release, compressed, pocket, now)
        if pocket == POCKETS[0]:
            exact_record(selected)
        else:
            need(not selected, "MOVING_PACKAGE_CHANGED")
        receipts[pocket] = {"inReleaseSha256": hashlib.sha256(inrelease).hexdigest(),
                            "indexSha512": digest, "indexBytes": len(compressed)}
    deb = fetch(opener, ARCHIVE + PACKAGE, PACKAGE_SIZE)
    executable = verified_package_member(deb)
    return deb, executable, {"archive": receipts, "keyringSha256": KEYRING_SHA256, "packageSha512": sha512(deb),
                              "binarySha256": hashlib.sha256(executable).hexdigest()}
