"""Unprivileged host-side inspection of a live C856 child tree."""
import hashlib
import os
import select
import stat
import time
from pathlib import Path
from package import file_identity

from boundary import BoundaryError, process_identity

PROC = Path("/proc")
DENIED_BROWSER_FLAGS = (
    "--no-sandbox", "--disable-namespace-sandbox", "--disable-seccomp-filter-sandbox",
    "--no-zygote", "--single-process", "--disable-gpu-sandbox", "--disable-sandbox",
)


def need(value, code):
    if not value:
        raise BoundaryError(code)


def bounded_read(path, bound):
    with path.open("rb") as stream:
        data = stream.read(bound + 1)
    need(0 < len(data) <= bound, "PROC_FIELD_BOUND")
    return data


def status(pid):
    data = bounded_read(PROC / str(pid) / "status", 32768).decode("ascii")
    return {line.split(":", 1)[0]: line.split(":", 1)[1].strip() for line in data.splitlines() if ":" in line}


def children_of(process):
    # Bubblewrap and Playwright can create children on distinct native threads.
    queue = [process]
    seen = {process}
    children = []
    while queue:
        parent = queue.pop(0)
        try:
            for thread in (PROC / str(parent) / "task").iterdir():
                try:
                    values = (thread / "children").read_text(encoding="ascii").split()
                except (FileNotFoundError, ProcessLookupError):
                    continue
                for value in values:
                    pid = int(value)
                    if pid in seen:
                        continue
                    need(len(seen) < 256, "PROCESS_TREE_BOUND")
                    seen.add(pid)
                    children.append(pid)
                    queue.append(pid)
        except (FileNotFoundError, ProcessLookupError):
            continue
    return children


def local_child(outer_pid, child_pid, depth):
    matches = []
    for candidate in children_of(outer_pid):
        try:
            ids = [int(value) for value in status(candidate)["NSpid"].split()]
        except (FileNotFoundError, ProcessLookupError):
            continue
        if len(ids) == depth + 1 and ids[-2] == child_pid:
            matches.append(candidate)
    need(len(matches) == 1, "AMBIGUOUS_NAMESPACE_CHILD")
    return matches[0]


def command(pid):
    raw = bounded_read(PROC / str(pid) / "cmdline", 64 << 10)
    need(raw.endswith(b"\0"), "CHROMIUM_ARGUMENT_FORMAT")
    return raw.rstrip(b"\0").decode("utf-8", errors="strict").split("\0")


def executable_digest(pid):
    with (PROC / str(pid) / "exe").open("rb") as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 512 << 20, "CHROMIUM_EXECUTABLE_SIZE")
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
        after = os.fstat(stream.fileno())
        need(file_identity(before) == file_identity(after), "CHROMIUM_EXECUTABLE_CHANGED")
    return digest


def bind_application_socket(app, port):
    network = PROC / str(app) / "net" / "tcp"
    rows = bounded_read(network, 1 << 20).decode("ascii").splitlines()[1:]
    endpoint = "0100007F:" + f"{port:04X}"
    matches = [row.split()[9] for row in rows if row.split()[1] == endpoint and row.split()[3] == "0A"]
    need(len(matches) == 1 and matches[0].isdigit(), "APP_LISTENER_IDENTITY")
    socket = "socket:[" + matches[0] + "]"
    owners = []
    for pid in children_of(app):
        try:
            for fd in (PROC / str(pid) / "fd").iterdir():
                try:
                    if os.readlink(fd) == socket:
                        owners.append(pid)
                        break
                except FileNotFoundError:
                    continue
        except (FileNotFoundError, ProcessLookupError):
            continue
    need(len(owners) == 1, "APP_LISTENER_NOT_OWNED")
    owner = owners[0]
    descriptor = os.pidfd_open(owner)
    try:
        identity = process_identity(owner, descriptor)
        need(owner in children_of(app) and
             any(os.readlink(fd) == socket for fd in (PROC / str(owner) / "fd").iterdir()),
             "APP_LISTENER_CHANGED")
        return {"owner": identity, "inode": matches[0], "port": port}, descriptor
    except BaseException:
        os.close(descriptor)
        raise



def verify_chromium_proc(worker, renderer):
    pid = worker["pid"]
    root = PROC / str(pid) / "root"
    entries = bounded_read(PROC / str(pid) / "mountinfo", 1 << 20).decode("ascii").splitlines()
    mounts = [line.split() for line in entries if line.split()[4] == "/proc"]
    need(len(mounts) == 1 and mounts[0][mounts[0].index("-") + 1] == "proc" and
         {"rw", "nodev", "nosuid", "noexec"}.issubset(set(mounts[0][5].split(","))), "CHROMIUM_PROC_MOUNT")
    need((root / "proc/sys").is_dir() and not any((root / "proc/sys").iterdir()), "PROC_GLOBAL_SYSCTL_VISIBLE")
    for filename in ("sysrq-trigger", "kcore"):
        candidate = root / "proc" / filename
        if candidate.exists():
            info = candidate.stat()
            need(stat.S_ISREG(info.st_mode) and info.st_size == 0, "PROC_GLOBAL_CONTROL_VISIBLE")
    uid = bounded_read(PROC / str(renderer["pid"]) / "uid_map", 4096).decode("ascii").split()
    gid = bounded_read(PROC / str(renderer["pid"]) / "gid_map", 4096).decode("ascii").split()
    groups = bounded_read(PROC / str(renderer["pid"]) / "setgroups", 64).strip()
    need(len(uid) == len(gid) == 3 and uid[2] == gid[2] == "1" and groups == b"deny",
         "CHROMIUM_PRIVATE_ID_MAP")



def bind_chromium(worker, worker_identity, expected_sha256, seconds=30):
    """Return externally observed live browser and sandboxed renderer with owned pidfds."""
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        tree = children_of(worker)
        matches = []
        for pid in tree:
            try:
                argv = command(pid)
            except (FileNotFoundError, ProcessLookupError, BoundaryError):
                continue
            if not argv[0].endswith(("/headless_shell", "/chrome-headless-shell", "/chrome")):
                continue
            if any(arg.split("=", 1)[0] in DENIED_BROWSER_FLAGS for arg in argv):
                raise BoundaryError("CHROMIUM_SANDBOX_DISABLED")
            if "--type=renderer" in argv:
                matches.append(pid)
        for renderer in matches:
            for chrome in tree:
                if renderer == chrome or renderer not in children_of(chrome):
                    continue
                try:
                    argv = command(chrome)
                    if not argv[0].endswith(("/headless_shell", "/chrome-headless-shell", "/chrome")) or any(
                        arg.startswith("--type=") for arg in argv
                    ):
                        continue
                    opened = []
                    try:
                        for pid in (chrome, renderer):
                            opened.append(os.pidfd_open(pid))
                        browser_identity = process_identity(chrome, opened[0])
                        renderer_identity = process_identity(renderer, opened[1])
                        if (browser_identity["namespaces"] != worker_identity["namespaces"] or
                            renderer_identity["namespaces"]["pid"] == browser_identity["namespaces"]["pid"] or
                            renderer_identity["namespaces"]["user"] == browser_identity["namespaces"]["user"] or
                            renderer_identity["seccomp"] != 2):
                            continue
                        need(all(executable_digest(pid) == expected_sha256 for pid in (chrome, renderer)),
                             "CHROMIUM_EXECUTABLE_DIGEST")
                        need(renderer in children_of(chrome) and chrome in children_of(worker),
                             "CHROMIUM_ANCESTRY_DRIFT")
                        need(process_identity(chrome, opened[0]) == browser_identity and
                             process_identity(renderer, opened[1]) == renderer_identity, "CHROMIUM_IDENTITY_DRIFT")
                        verify_chromium_proc(worker_identity, renderer_identity)
                        result = (browser_identity, renderer_identity, tuple(opened))
                        opened.clear()
                        return result
                    finally:
                        for fd in opened:
                            os.close(fd)
                except (FileNotFoundError, ProcessLookupError):
                    continue
        time.sleep(.05)
    raise BoundaryError("CHROMIUM_NATIVE_SANDBOX_UNOBSERVED")


def wait_pidfds(fds, timeout_ms):
    selector = select.poll()
    for fd in fds:
        selector.register(fd, select.POLLIN | select.POLLHUP | select.POLLERR)
    remain = set(fds)
    deadline = time.monotonic() + timeout_ms / 1000
    while remain:
        events = selector.poll(max(0, int((deadline - time.monotonic()) * 1000)))
        need(bool(events) and time.monotonic() <= deadline, "PIDFD_TEARDOWN_DEADLINE")
        for fd, flags in events:
            need(flags & (select.POLLIN | select.POLLHUP) and fd in remain, "PIDFD_TEARDOWN")
            remain.remove(fd)
            selector.unregister(fd)
